#define _CRT_SECURE_NO_WARNINGS
#include "gui_app.h"
#include "tema.h"
#include "imgui.h"

#include <cstring>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>
#include "../nomina/desglose_anual.h"

namespace pita {

// ======================================================================
// HELPERS MONEDA Y FORMATO
// ======================================================================

static std::string formatearMoneda(double valor) {
    long long entero = static_cast<long long>(std::round(valor));
    std::string s = std::to_string(std::abs(entero));
    std::string res;
    int count = 0;
    for (int i = static_cast<int>(s.length()) - 1; i >= 0; --i) {
        res.insert(res.begin(), s[i]);
        count++;
        if (count % 3 == 0 && i > 0) {
            res.insert(res.begin(), '.');
        }
    }
    std::string signo = (entero < 0) ? "-$" : "$";
    return signo + " " + res + " COP";
}

static std::string getNombreDocente(const GUIController& ctrl, int idProfesor) {
    for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
        auto& prof = ctrl.datos.profesores.obtener(i);
        if (prof.idProfesor && *prof.idProfesor == idProfesor) {
            for (size_t j = 0; j < ctrl.datos.personas.tamano(); ++j) {
                auto& p = ctrl.datos.personas.obtener(j);
                if (p.idPersona && prof.idPersona && *p.idPersona == *prof.idPersona) {
                    std::string nombre = (p.primerNombre ? *p.primerNombre : "") + " " + (p.primerApellido ? *p.primerApellido : "");
                    if (!nombre.empty() && nombre != " ") return nombre;
                }
            }
            if (prof.codigoProfesor) return *prof.codigoProfesor;
            return "Docente #" + std::to_string(idProfesor);
        }
    }
    return "Docente #" + std::to_string(idProfesor);
}

static std::string getNombreAdministrativo(const GUIController& ctrl, int idAdministrativo) {
    for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
        auto& adm = ctrl.datos.administrativos.obtener(i);
        if (adm.idAdministrativo && *adm.idAdministrativo == idAdministrativo) {
            for (size_t j = 0; j < ctrl.datos.personas.tamano(); ++j) {
                auto& p = ctrl.datos.personas.obtener(j);
                if (p.idPersona && adm.idPersona && *p.idPersona == *adm.idPersona) {
                    std::string nombre = (p.primerNombre ? *p.primerNombre : "") + " " + (p.primerApellido ? *p.primerApellido : "");
                    if (!nombre.empty() && nombre != " ") return nombre;
                }
            }
            if (adm.codigoEmpleado) return *adm.codigoEmpleado;
            return "Administrativo #" + std::to_string(idAdministrativo);
        }
    }
    return "Administrativo #" + std::to_string(idAdministrativo);
}

static std::string getNombreEmpleado(const GUIController& ctrl, const LiquidacionNomina& liq) {
    if (liq.idProfesor.has_value() && *liq.idProfesor > 0) {
        return getNombreDocente(ctrl, *liq.idProfesor);
    }
    if (liq.idContrato.has_value()) {
        for (size_t i = 0; i < ctrl.datos.contratos.tamano(); ++i) {
            auto& c = ctrl.datos.contratos.obtener(i);
            if (c.idContrato && *c.idContrato == *liq.idContrato && c.idPersona) {
                for (size_t j = 0; j < ctrl.datos.personas.tamano(); ++j) {
                    auto& p = ctrl.datos.personas.obtener(j);
                    if (p.idPersona && *p.idPersona == *c.idPersona) {
                        std::string nombre = (p.primerNombre ? *p.primerNombre : "") + " " + (p.primerApellido ? *p.primerApellido : "");
                        if (!nombre.empty() && nombre != " ") return nombre;
                    }
                }
            }
        }
    }
    return "Funcionario #" + std::to_string(liq.idContrato.value_or(0));
}

// ======================================================================
// VISTA: NÓMINA & LIQUIDACIÓN
// ======================================================================

void PITAApp::renderNomina() {
    if (fuenteTitulo) ImGui::PushFont(fuenteTitulo);
    ImGui::TextColored(tema::TEXT_MAIN(), "Subsistema de Nomina & Prestaciones Sociales (PITA)");
    if (fuenteTitulo) ImGui::PopFont();

    if (fuentePequena) ImGui::PushFont(fuentePequena);
    ImGui::TextColored(tema::TEXT_MUTED(), "Liquidacion salarial docente, descuentos de ley y aportes patronales (Decreto 1279 / Acuerdo 027)");
    if (fuentePequena) ImGui::PopFont();

    ImGui::Spacing();

    // Botones de acción principales (Header)
    if (ImGui::Button("Periodos de Nomina", ImVec2(165, 34))) {
        perAnio = 2026;
        perMes = 3;
        mensajeModal[0] = '\0';
        errorModal = false;
        modalPeriodoNominaAbierto = true;
    }
    ImGui::SameLine();
    if (ImGui::Button("Liquidar Empleado", ImVec2(165, 34))) {
        mensajeModal[0] = '\0';
        errorModal = false;
        modalLiquidarIndividualAbierto = true;
    }
    ImGui::SameLine();
    if (ImGui::Button("Liquidar Periodo Completo", ImVec2(205, 34))) {
        ejecutarLiquidacionGeneral();
    }

    ImGui::Spacing();

    // Selector de Período Activo
    ImGui::TextColored(tema::TEXT_MUTED(), "Periodo de Nomina Activo:");
    ImGui::SameLine();

    std::string previewFiltro = (nomFiltroPeriodoId == 0) ? "Todos los Periodos Registrados" : ("Periodo #" + std::to_string(nomFiltroPeriodoId));
    std::string estadoPeriodoSel = "";
    for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
        auto& p = ctrl.datos.periodosNomina.obtener(i);
        if (p.idPeriodoNomina && *p.idPeriodoNomina == nomFiltroPeriodoId) {
            estadoPeriodoSel = p.estado.value_or("ABIERTO");
            previewFiltro = "Periodo #" + std::to_string(*p.idPeriodoNomina) + " (" +
                            std::to_string(p.anio.value_or(2026)) + "-" + std::to_string(p.mes.value_or(1)) + ") [" +
                            estadoPeriodoSel + "]";
            break;
        }
    }
    ImGui::SetNextItemWidth(360);
    if (ImGui::BeginCombo("##FiltroPeriodoNomina", previewFiltro.c_str())) {
        if (ImGui::Selectable("Todos los Periodos Registrados", nomFiltroPeriodoId == 0)) {
            nomFiltroPeriodoId = 0;
        }
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (!p.idPeriodoNomina) continue;
            bool sel = (*p.idPeriodoNomina == nomFiltroPeriodoId);
            std::string lbl = "Periodo #" + std::to_string(*p.idPeriodoNomina) + " (" +
                              std::to_string(p.anio.value_or(2026)) + "-" + std::to_string(p.mes.value_or(1)) + ") [" +
                              (p.estado ? *p.estado : "ABIERTO") + "]";
            if (ImGui::Selectable(lbl.c_str(), sel)) {
                nomFiltroPeriodoId = *p.idPeriodoNomina;
            }
            if (sel) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    if (!estadoPeriodoSel.empty()) {
        ImGui::SameLine();
        if (estadoPeriodoSel == "ABIERTO") {
            ImGui::TextColored(ImVec4(0.10f, 0.80f, 0.45f, 1.0f), "[PERIODO EN PROCESO - ABIERTO]");
        } else {
            ImGui::TextColored(tema::ACCENT_DANGER(), "[PERIODO AUDITADO - CERRADO]");
        }
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Spacing();

    // Cálculo de acumulados financieros (KPIs) filtrados por período
    double tot_dev = 0.0;
    double tot_desc = 0.0;
    double tot_neto = 0.0;
    double tot_prest = 0.0;
    for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
        auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
        if (nomFiltroPeriodoId > 0 && l.idPeriodoNomina.value_or(0) != nomFiltroPeriodoId) {
            continue;
        }
        tot_dev += l.totalDevengado.value_or(0.0);
        tot_desc += l.totalDescuentos.value_or(0.0);
        tot_neto += l.netoPagar.value_or(0.0);
        tot_prest += l.totalPrestaciones.value_or(0.0);
    }

    // 4 Tarjetas KPI de resumen organizadas en Grid horizontal
    if (ImGui::BeginTable("##GridKPINomina", 4, ImGuiTableFlags_SizingStretchSame)) {
        ImGui::TableNextColumn();
        tarjetaKPI("Total Devengado (Bruto)", formatearMoneda(tot_dev).c_str(), tema::WIN_BLUE(), "Ingreso base devengado periodo");

        ImGui::TableNextColumn();
        tarjetaKPI("Deducciones de Ley", formatearMoneda(tot_desc).c_str(), tema::ACCENT_DANGER(), "Salud, pension y retenciones");

        ImGui::TableNextColumn();
        tarjetaKPI("Neto Total a Pagar", formatearMoneda(tot_neto).c_str(), ImVec4(0.063f, 0.725f, 0.506f, 1.0f), "Gasto liquido a transferir");

        ImGui::TableNextColumn();
        tarjetaKPI("Prestaciones Proyectadas", formatearMoneda(tot_prest).c_str(), tema::ACCENT_WARNING(), "Cesantias, primas y vacaciones");

        ImGui::EndTable();
    }
    ImGui::Spacing();

    // Pestañas temáticas idénticas a Python
    if (ImGui::BeginTabBar("##TabsNominaPITA")) {

        // --------------------------------------------------------------
        // Pestaña 1: Resumen de Liquidaciones
        // --------------------------------------------------------------
        if (ImGui::BeginTabItem("Resumen de Liquidaciones")) {
            ImGui::Spacing();

            if (ctrl.datos.liquidacionesNomina.tamano() == 0) {
                ImGui::BeginChild("##VacioLiquidaciones", ImVec2(0, 180), true);
                ImGui::Spacing();
                ImGui::Spacing();
                ImGui::TextColored(tema::TEXT_MUTED(), "No se han generado liquidaciones de nomina en este periodo.");
                ImGui::Spacing();
                if (ImGui::Button("Calcular Liquidaciones del Periodo Ahora", ImVec2(280, 36))) {
                    ejecutarLiquidacionGeneral();
                }
                ImGui::EndChild();
            } else {
                if (ImGui::BeginTable("##TablaResumenLiquidaciones", 8,
                    ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersOuter | ImGuiTableFlags_BordersInnerH |
                    ImGuiTableFlags_Resizable | ImGuiTableFlags_ScrollY, ImVec2(0, 0))) {

                    ImGui::TableSetupColumn("Empleado / Funcionario", ImGuiTableColumnFlags_WidthStretch, 2.0f);
                    ImGui::TableSetupColumn("Tipo / Cargo", ImGuiTableColumnFlags_WidthFixed, 140.0f);
                    ImGui::TableSetupColumn("Sueldo Basico", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                    ImGui::TableSetupColumn("Devengado", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                    ImGui::TableSetupColumn("Descuentos Ley", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                    ImGui::TableSetupColumn("Neto a Pagar", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                    ImGui::TableSetupColumn("Prestaciones", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                    ImGui::TableSetupColumn("Acciones", ImGuiTableColumnFlags_WidthFixed, 220.0f);
                    ImGui::TableHeadersRow();

                    for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
                        auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
                        if (nomFiltroPeriodoId > 0 && l.idPeriodoNomina.value_or(0) != nomFiltroPeriodoId) {
                            continue;
                        }
                        int idLiq = l.idLiquidacion.value_or(0);

                        std::string nombre = getNombreEmpleado(ctrl, l);
                        bool esAdmin = (!l.idProfesor.has_value() || *l.idProfesor == 0 ||
                                       (l.regimenLiquidado && (l.regimenLiquidado->find("CST") != std::string::npos || l.regimenLiquidado->find("ADMINISTRATIVO") != std::string::npos)));
                        std::string tipoDocente = l.tipoProfesorLiquidado ? to_string(*l.tipoProfesorLiquidado) : "PLANTA";

                        ImGui::TableNextRow();
                        // 1. Empleado
                        ImGui::TableNextColumn();
                        ImGui::TextColored(tema::TEXT_MAIN(), "%s", nombre.c_str());

                        // 2. Tipo / Cargo (Badge)
                        ImGui::TableNextColumn();
                        if (esAdmin) {
                            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.06f, 0.40f, 0.35f, 0.35f));
                            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.30f, 0.90f, 0.75f, 1.0f));
                            std::string badgeCargo = l.categoriaLiquidada.value_or("ADMINISTRATIVO");
                            ImGui::SmallButton(badgeCargo.c_str());
                            ImGui::PopStyleColor(2);
                        } else if (tipoDocente.find("PLANTA") != std::string::npos) {
                            ImGui::PushStyleColor(ImGuiCol_Button, tema::BADGE_ACTIVE_BG());
                            ImGui::PushStyleColor(ImGuiCol_Text, tema::BADGE_ACTIVE_TXT());
                            ImGui::SmallButton("PLANTA");
                            ImGui::PopStyleColor(2);
                        } else if (tipoDocente.find("OCASIONAL") != std::string::npos) {
                            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.35f, 0.20f, 0.50f, 0.35f));
                            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.55f, 0.95f, 1.0f));
                            ImGui::SmallButton("OCASIONAL");
                            ImGui::PopStyleColor(2);
                        } else {
                            ImGui::PushStyleColor(ImGuiCol_Button, tema::BADGE_INFO_BG());
                            ImGui::PushStyleColor(ImGuiCol_Text, tema::BADGE_INFO_TXT());
                            ImGui::SmallButton("CATEDRATICO");
                            ImGui::PopStyleColor(2);
                        }

                        // 3. Sueldo Básico
                        ImGui::TableNextColumn();
                        ImGui::Text("%s", formatearMoneda(l.salarioBase.value_or(0.0)).c_str());

                        // 4. Devengado
                        ImGui::TableNextColumn();
                        ImGui::TextColored(tema::WIN_BLUE(), "%s", formatearMoneda(l.totalDevengado.value_or(0.0)).c_str());

                        // 5. Descuentos Ley
                        ImGui::TableNextColumn();
                        ImGui::TextColored(tema::ACCENT_DANGER(), "%s", formatearMoneda(l.totalDescuentos.value_or(0.0)).c_str());

                        // 6. Neto a Pagar
                        ImGui::TableNextColumn();
                        ImGui::TextColored(ImVec4(0.063f, 0.725f, 0.506f, 1.0f), "%s", formatearMoneda(l.netoPagar.value_or(0.0)).c_str());

                        // 7. Prestaciones
                        ImGui::TableNextColumn();
                        ImGui::TextColored(tema::ACCENT_WARNING(), "%s", formatearMoneda(l.totalPrestaciones.value_or(0.0)).c_str());

                        // 8. Acciones
                        ImGui::TableNextColumn();
                        ImGui::PushID(static_cast<int>(i));
                        if (ImGui::SmallButton("Desglose")) {
                            idLiquidacionDesprendible = idLiq;
                            modalDesprendibleAbierto = true;
                        }

                        bool perCerrado = false;
                        if (l.idPeriodoNomina) {
                            for (size_t pidx = 0; pidx < ctrl.datos.periodosNomina.tamano(); ++pidx) {
                                auto& pcheck = ctrl.datos.periodosNomina.obtener(pidx);
                                if (pcheck.idPeriodoNomina && *pcheck.idPeriodoNomina == *l.idPeriodoNomina) {
                                    perCerrado = pcheck.estaCerrado.value_or(false) || (pcheck.estado && *pcheck.estado == "CERRADO");
                                    break;
                                }
                            }
                        }
                        if (!perCerrado) {
                            bool pagada = l.pagada.value_or(false) || (l.estado && *l.estado == "PAGADA");
                            if (!pagada) {
                                ImGui::SameLine();
                                ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.47f, 0.05f, 0.70f));
                                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
                                if (ImGui::SmallButton("Reliquidar")) {
                                    try {
                                        ctrl.gestorNomina->cicloVida.reliquidar(idLiq);
                                        ctrl.guardarDatos();
                                    } catch (...) {}
                                }
                                ImGui::PopStyleColor(2);
                            }
                            ImGui::SameLine();
                            if (ImGui::SmallButton("Anular")) {
                                eliminarLiquidacion(idLiq);
                            }
                        }
                        ImGui::PopID();
                    }
                    ImGui::EndTable();
                }
            }
            ImGui::EndTabItem();
        }

        // --------------------------------------------------------------
        // Pestaña 2: Aportes Patronales & Parafiscales
        // --------------------------------------------------------------
        if (ImGui::BeginTabItem("Aportes Patronales & Parafiscales")) {
            ImGui::Spacing();
            ImGui::TextColored(tema::TEXT_MAIN(), "Aportes Patronales a la Seguridad Social y Parafiscales");
            ImGui::TextColored(tema::TEXT_MUTED(), "Calculados sobre el Ingreso Base de Cotizacion (IBC total devengado periodo).");
            ImGui::Spacing();

            double tot_ibc = tot_dev;
            double salud_pat = tot_ibc * 0.085;
            double pension_pat = tot_ibc * 0.12;
            double arl = tot_ibc * 0.00522;
            double sena = tot_ibc * 0.02;
            double icbf = tot_ibc * 0.03;
            double caja = tot_ibc * 0.04;
            double total_patronal = salud_pat + pension_pat + arl + sena + icbf + caja;

            if (ImGui::BeginTable("##TablaParafiscalesPatronal", 3,
                ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersOuter | ImGuiTableFlags_BordersInnerH |
                ImGuiTableFlags_Resizable, ImVec2(0, 0))) {

                ImGui::TableSetupColumn("Concepto Parafiscal / Patronal", ImGuiTableColumnFlags_WidthStretch, 2.0f);
                ImGui::TableSetupColumn("Monto Proyectado", ImGuiTableColumnFlags_WidthFixed, 180.0f);
                ImGui::TableSetupColumn("Norma Legal Origen", ImGuiTableColumnFlags_WidthStretch, 2.0f);
                ImGui::TableHeadersRow();

                struct FilaParafiscal {
                    const char* concepto;
                    double monto;
                    const char* norma;
                };
                FilaParafiscal filas[] = {
                    { "Salud Patronal (8.5 %)", salud_pat, "Ley 100 de 1993, Art. 204" },
                    { "Pension Patronal (12.0 %)", pension_pat, "Ley 100 de 1993, Art. 20" },
                    { "ARL Riesgos Laborales (0.522 %)", arl, "Decreto 1772 de 1994, Art. 13" },
                    { "SENA (2.0 %)", sena, "Ley 21 de 1982, Art. 7" },
                    { "ICBF (3.0 %)", icbf, "Ley 89 de 1988, Art. 1" },
                    { "Caja de Compensacion Familiar (4.0 %)", caja, "Ley 21 de 1982, Art. 7" }
                };

                for (const auto& f : filas) {
                    ImGui::TableNextRow();
                    ImGui::TableNextColumn();
                    ImGui::Text("%s", f.concepto);
                    ImGui::TableNextColumn();
                    ImGui::TextColored(tema::WIN_BLUE(), "%s", formatearMoneda(f.monto).c_str());
                    ImGui::TableNextColumn();
                    ImGui::TextColored(tema::TEXT_MUTED(), "%s", f.norma);
                }
                ImGui::EndTable();
            }

            ImGui::Spacing();
            ImGui::BeginChild("##CardTotalPatronal", ImVec2(0, 56), true);
            ImGui::TextColored(ImVec4(0.063f, 0.725f, 0.506f, 1.0f), "Carga Prestacional y Patronal Total Estimada: %s", formatearMoneda(total_patronal).c_str());
            ImGui::TextColored(tema::TEXT_MUTED(), "Provision mensual estimada para costos directos de nomina institucional.");
            ImGui::EndChild();

            ImGui::EndTabItem();
        }

        // --------------------------------------------------------------
        // Pestaña 3: Desglose de Nomina Anual (12 Meses)
        // --------------------------------------------------------------
        if (ImGui::BeginTabItem("Desglose de Nomina Anual")) {
            ImGui::Spacing();
            ImGui::TextColored(tema::TEXT_MAIN(), "Consolidacion Presupuestal y Proyeccion Anual de Nomina (12 Meses)");
            ImGui::TextColored(tema::TEXT_MUTED(), "Devengados, descuentos de ley, pasivo prestacional consolidado y aportes patronales UPC.");
            ImGui::Spacing();

            // Toolbar superior de filtros
            std::string previewContrato = "Consolidado Institucional UPC (Todos los contratos)";
            if (desgloseContratoSeleccionadoId > 0) {
                for (size_t i = 0; i < ctrl.datos.contratos.tamano(); ++i) {
                    auto& c = ctrl.datos.contratos.obtener(i);
                    if (c.idContrato && *c.idContrato == desgloseContratoSeleccionadoId) {
                        std::string nom = "Contrato #" + std::to_string(desgloseContratoSeleccionadoId);
                        if (c.idPersona) {
                            for (size_t j = 0; j < ctrl.datos.personas.tamano(); ++j) {
                                auto& p = ctrl.datos.personas.obtener(j);
                                if (p.idPersona && *p.idPersona == *c.idPersona) {
                                    nom = (p.primerNombre ? *p.primerNombre : "") + " " + (p.primerApellido ? *p.primerApellido : "");
                                    break;
                                }
                            }
                        }
                        previewContrato = nom + " (" + (c.tipoContrato ? *c.tipoContrato : "CONTRATO") + ")";
                        break;
                    }
                }
            }

            ImGui::SetNextItemWidth(380);
            if (ImGui::BeginCombo("Seleccionar Alcance *", previewContrato.c_str())) {
                bool selInst = (desgloseContratoSeleccionadoId == 0);
                if (ImGui::Selectable("Consolidado Institucional UPC (Todos los contratos)", selInst)) {
                    desgloseContratoSeleccionadoId = 0;
                }
                if (selInst) ImGui::SetItemDefaultFocus();

                for (size_t i = 0; i < ctrl.datos.contratos.tamano(); ++i) {
                    auto& c = ctrl.datos.contratos.obtener(i);
                    int idC = c.idContrato.value_or(0);
                    std::string nom = "Contrato #" + std::to_string(idC);
                    if (c.idPersona) {
                        for (size_t j = 0; j < ctrl.datos.personas.tamano(); ++j) {
                            auto& p = ctrl.datos.personas.obtener(j);
                            if (p.idPersona && *p.idPersona == *c.idPersona) {
                                nom = (p.primerNombre ? *p.primerNombre : "") + " " + (p.primerApellido ? *p.primerApellido : "");
                                break;
                            }
                        }
                    }
                    std::string lbl = nom + " (" + (c.tipoContrato ? *c.tipoContrato : "CONTRATO") + ") [ID: " + std::to_string(idC) + "]";
                    bool sel = (desgloseContratoSeleccionadoId == idC);
                    if (ImGui::Selectable(lbl.c_str(), sel)) {
                        desgloseContratoSeleccionadoId = idC;
                    }
                    if (sel) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }

            ImGui::SameLine();
            ImGui::SetNextItemWidth(100);
            ImGui::InputInt("Ano Fiscal", &desgloseAnio, 0);

            ImGui::SameLine();
            if (ImGui::Button("Informe Texto Plano", ImVec2(160, 26))) {
                if (ctrl.gestorNomina) {
                    CalculadorDesgloseAnual calc(*ctrl.gestorNomina, &ctrl.datos.personas);
                    reporteAnualTexto = calc.generarInformeTexto(desgloseAnio);
                    modalReporteAnualAbierto = true;
                }
            }

            ImGui::SameLine();
            if (ImGui::Button("Exportar Markdown", ImVec2(150, 26))) {
                if (ctrl.gestorNomina) {
                    CalculadorDesgloseAnual calc(*ctrl.gestorNomina, &ctrl.datos.personas);
                    reporteAnualTexto = calc.generarInformeMarkdown(desgloseAnio);
                    modalReporteAnualAbierto = true;
                }
            }

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Spacing();

            if (ctrl.gestorNomina) {
                if (desgloseContratoSeleccionadoId > 0) {
                    // DESGLOSE INDIVIDUAL POR CONTRATO
                    auto d = ctrl.gestorNomina->desgloseNominaAnual(desgloseContratoSeleccionadoId, desgloseAnio);

                    ImGui::TextColored(tema::WIN_BLUE(), "Desglose Funcionario: %s (Doc: %s)", d.nombreCompleto.c_str(), d.identificacion.c_str());
                    ImGui::TextColored(tema::TEXT_MUTED(), "Modalidad: %s | Regimen: %s | Proyeccion: %d meses (%d dias)",
                                       d.tipoPersonal.c_str(), d.regimen.c_str(), d.mesesConsiderados, d.diasTrabajadosAnio);
                    ImGui::Spacing();

                    // 4 Tarjetas KPI Individuales
                    if (ImGui::BeginTable("##GridKPIAnualInd", 4, ImGuiTableFlags_SizingStretchSame)) {
                        ImGui::TableNextColumn();
                        tarjetaKPI("Devengado Anual", formatearMoneda(d.totalDevengadoAnual).c_str(), tema::WIN_BLUE(), "Salario base + bonificaciones");

                        ImGui::TableNextColumn();
                        tarjetaKPI("Deducciones Anuales", formatearMoneda(d.totalDescuentosAnual).c_str(), tema::ACCENT_DANGER(), "Salud, pension, FSP, retenciones");

                        ImGui::TableNextColumn();
                        tarjetaKPI("Neto Anual Trabajador", formatearMoneda(d.netoAnualTrabajador).c_str(), ImVec4(0.063f, 0.725f, 0.506f, 1.0f), "Ingreso liquido anual");

                        ImGui::TableNextColumn();
                        tarjetaKPI("Costo Total Empleador", formatearMoneda(d.costoTotalEmpleadorAnual).c_str(), tema::ACCENT_WARNING(), "Devengado + Prestaciones + Patronales");

                        ImGui::EndTable();
                    }
                    ImGui::Spacing();

                    // Tabla Detallada Concepto a Concepto
                    if (ImGui::BeginTable("##TablaItemsDesglose", 7,
                        ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersOuter | ImGuiTableFlags_BordersInnerH |
                        ImGuiTableFlags_Resizable | ImGuiTableFlags_ScrollY, ImVec2(0, 320))) {

                        ImGui::TableSetupColumn("Concepto", ImGuiTableColumnFlags_WidthStretch, 1.8f);
                        ImGui::TableSetupColumn("Categoria", ImGuiTableColumnFlags_WidthFixed, 130.0f);
                        ImGui::TableSetupColumn("Base Calculo", ImGuiTableColumnFlags_WidthFixed, 125.0f);
                        ImGui::TableSetupColumn("Factor / %", ImGuiTableColumnFlags_WidthFixed, 95.0f);
                        ImGui::TableSetupColumn("Promedio Mes", ImGuiTableColumnFlags_WidthFixed, 125.0f);
                        ImGui::TableSetupColumn("Consolidado Anual", ImGuiTableColumnFlags_WidthFixed, 140.0f);
                        ImGui::TableSetupColumn("Observaciones / Fundamento", ImGuiTableColumnFlags_WidthStretch, 2.0f);
                        ImGui::TableHeadersRow();

                        for (const auto& it : d.items) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::Text("%s", it.concepto.c_str());

                            ImGui::TableNextColumn();
                            if (it.categoria == "DEVENGADO") {
                                ImGui::TextColored(ImVec4(0.10f, 0.80f, 0.45f, 1.0f), "DEVENGADO");
                            } else if (it.categoria == "DEDUCCION") {
                                ImGui::TextColored(tema::ACCENT_DANGER(), "DEDUCCION");
                            } else if (it.categoria == "PRESTACION") {
                                ImGui::TextColored(tema::ACCENT_WARNING(), "PRESTACION");
                            } else {
                                ImGui::TextColored(tema::WIN_BLUE(), "PATRONAL");
                            }

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", formatearMoneda(it.baseCalculo).c_str());

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", it.porcentajeOFactor.c_str());

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", formatearMoneda(it.valorMensualPromedio).c_str());

                            ImGui::TableNextColumn();
                            ImGui::TextColored(tema::WIN_BLUE(), "%s", formatearMoneda(it.valorAnualConsolidado).c_str());

                            ImGui::TableNextColumn();
                            ImGui::TextColored(tema::TEXT_MUTED(), "%s", it.observaciones.c_str());
                        }
                        ImGui::EndTable();
                    }

                    ImGui::Spacing();
                    ImGui::BeginChild("##ResumenCargasInd", ImVec2(0, 56), true);
                    ImGui::TextColored(ImVec4(0.063f, 0.725f, 0.506f, 1.0f),
                        "Pasivo Prestacional Anual: %s | Carga Seguridad Social y Parafiscal UPC: %s",
                        formatearMoneda(d.totalPrestacionesAnuales).c_str(),
                        formatearMoneda(d.totalAportesPatronalesAnual).c_str());
                    ImGui::TextColored(tema::TEXT_MUTED(),
                        "Cesantias (8.33%%), Intereses (1%%), Prima Servicios (8.33%%), Vacaciones (4.17%%), Prima Vacaciones (5.56%%), Bonif. Servicios, Prima Navidad.");
                    ImGui::EndChild();

                } else {
                    // CONSOLIDADO INSTITUCIONAL UPC (TODOS LOS CONTRATOS)
                    auto res = ctrl.gestorNomina->resumenNominaAnual(desgloseAnio);

                    ImGui::TextColored(tema::WIN_BLUE(), "Resumen Institucional Global UPC - Presupuesto Anual %d", desgloseAnio);
                    ImGui::TextColored(tema::TEXT_MUTED(), "Consolidado de %d contratos analizados (Planta, Ocasionales, Catedra, Administrativos).", res.totalEmpleados);
                    ImGui::Spacing();

                    // 4 Tarjetas KPI Globales
                    if (ImGui::BeginTable("##GridKPIGlobal", 4, ImGuiTableFlags_SizingStretchSame)) {
                        ImGui::TableNextColumn();
                        tarjetaKPI("Devengado UPC", formatearMoneda(res.totalDevengadoAnual).c_str(), tema::WIN_BLUE(), "Masa bruta de salarios");

                        ImGui::TableNextColumn();
                        tarjetaKPI("Deducciones Retenidas", formatearMoneda(res.totalDeduccionesAnual).c_str(), tema::ACCENT_DANGER(), "Aportes ley de empleados");

                        ImGui::TableNextColumn();
                        tarjetaKPI("Neto Pagado al Personal", formatearMoneda(res.netoAnualTotal).c_str(), ImVec4(0.063f, 0.725f, 0.506f, 1.0f), "Total dispersion anual");

                        ImGui::TableNextColumn();
                        tarjetaKPI("Presupuesto Anual UPC", formatearMoneda(res.costoTotalInstitucional).c_str(), tema::ACCENT_WARNING(), "Costo total empleador 12 meses");

                        ImGui::EndTable();
                    }
                    ImGui::Spacing();

                    // Sub-tabla 1: Distribución por Modalidad de Personal
                    ImGui::TextColored(tema::TEXT_MAIN(), "Distribucion Presupuestal por Tipo de Personal:");
                    if (ImGui::BeginTable("##TablaPorTipoPersonal", 8,
                        ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersOuter | ImGuiTableFlags_BordersInnerH |
                        ImGuiTableFlags_Resizable, ImVec2(0, 0))) {

                        ImGui::TableSetupColumn("Tipo Personal", ImGuiTableColumnFlags_WidthFixed, 140.0f);
                        ImGui::TableSetupColumn("Contratos", ImGuiTableColumnFlags_WidthFixed, 75.0f);
                        ImGui::TableSetupColumn("Devengado", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                        ImGui::TableSetupColumn("Deducciones", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                        ImGui::TableSetupColumn("Neto Personal", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                        ImGui::TableSetupColumn("Prestaciones", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                        ImGui::TableSetupColumn("Aportes UPC", ImGuiTableColumnFlags_WidthFixed, 120.0f);
                        ImGui::TableSetupColumn("Costo Empleador", ImGuiTableColumnFlags_WidthStretch);
                        ImGui::TableHeadersRow();

                        for (const auto& [tipo, g] : res.porTipoPersonal) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn(); ImGui::TextColored(tema::WIN_BLUE(), "%s", tipo.c_str());
                            ImGui::TableNextColumn(); ImGui::Text("%d", g.cantidadContratos);
                            ImGui::TableNextColumn(); ImGui::Text("%s", formatearMoneda(g.totalDevengado).c_str());
                            ImGui::TableNextColumn(); ImGui::Text("%s", formatearMoneda(g.totalDeducciones).c_str());
                            ImGui::TableNextColumn(); ImGui::Text("%s", formatearMoneda(g.totalNeto).c_str());
                            ImGui::TableNextColumn(); ImGui::Text("%s", formatearMoneda(g.totalPrestaciones).c_str());
                            ImGui::TableNextColumn(); ImGui::Text("%s", formatearMoneda(g.totalAportesPatronales).c_str());
                            ImGui::TableNextColumn(); ImGui::TextColored(tema::ACCENT_WARNING(), "%s", formatearMoneda(g.costoTotalEmpleador).c_str());
                        }
                        ImGui::EndTable();
                    }

                    ImGui::Spacing();
                    ImGui::TextColored(tema::TEXT_MAIN(), "Detalle Anualizado Contrato por Contrato:");

                    // Sub-tabla 2: Detalle Contrato por Contrato
                    if (ImGui::BeginTable("##TablaDesglosesGlobal", 9,
                        ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersOuter | ImGuiTableFlags_BordersInnerH |
                        ImGuiTableFlags_Resizable | ImGuiTableFlags_ScrollY, ImVec2(0, 260))) {

                        ImGui::TableSetupColumn("Empleado / Cargo", ImGuiTableColumnFlags_WidthStretch, 1.8f);
                        ImGui::TableSetupColumn("Modalidad", ImGuiTableColumnFlags_WidthFixed, 110.0f);
                        ImGui::TableSetupColumn("Meses", ImGuiTableColumnFlags_WidthFixed, 60.0f);
                        ImGui::TableSetupColumn("Devengado Anual", ImGuiTableColumnFlags_WidthFixed, 115.0f);
                        ImGui::TableSetupColumn("Deducciones", ImGuiTableColumnFlags_WidthFixed, 115.0f);
                        ImGui::TableSetupColumn("Neto Anual", ImGuiTableColumnFlags_WidthFixed, 115.0f);
                        ImGui::TableSetupColumn("Prestaciones", ImGuiTableColumnFlags_WidthFixed, 115.0f);
                        ImGui::TableSetupColumn("Costo Empleador", ImGuiTableColumnFlags_WidthFixed, 130.0f);
                        ImGui::TableSetupColumn("Accion", ImGuiTableColumnFlags_WidthFixed, 100.0f);
                        ImGui::TableHeadersRow();

                        for (const auto& ind : res.desglosesIndividuales) {
                            ImGui::TableNextRow();
                            ImGui::TableNextColumn();
                            ImGui::Text("%s", ind.nombreCompleto.c_str());

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", ind.tipoPersonal.c_str());

                            ImGui::TableNextColumn();
                            ImGui::Text("%d m", ind.mesesConsiderados);

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", formatearMoneda(ind.totalDevengadoAnual).c_str());

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", formatearMoneda(ind.totalDescuentosAnual).c_str());

                            ImGui::TableNextColumn();
                            ImGui::TextColored(ImVec4(0.10f, 0.80f, 0.45f, 1.0f), "%s", formatearMoneda(ind.netoAnualTrabajador).c_str());

                            ImGui::TableNextColumn();
                            ImGui::Text("%s", formatearMoneda(ind.totalPrestacionesAnuales).c_str());

                            ImGui::TableNextColumn();
                            ImGui::TextColored(tema::ACCENT_WARNING(), "%s", formatearMoneda(ind.costoTotalEmpleadorAnual).c_str());

                            ImGui::TableNextColumn();
                            ImGui::PushID(ind.idContrato);
                            if (ImGui::SmallButton("Ver Detalle")) {
                                desgloseContratoSeleccionadoId = ind.idContrato;
                            }
                            ImGui::PopID();
                        }
                        ImGui::EndTable();
                    }
                }
            }

            ImGui::EndTabItem();
        }

        // --------------------------------------------------------------
        // Pestaña 4: Reglas Decreto 1279 / Acuerdo 027
        // --------------------------------------------------------------
        if (ImGui::BeginTabItem("Reglas Decreto 1279 / Acuerdo 027")) {
            ImGui::Spacing();
            ImGui::TextColored(tema::TEXT_MAIN(), "Marco Normativo Salarial Docente PITA");
            ImGui::Spacing();

            ImGui::BeginChild("##CardNormatividad", ImVec2(0, 360), true);
            ImGui::TextColored(tema::WIN_BLUE(), "1. Profesores de Planta (Decreto 1279 de 2002):");
            ImGui::BulletText("Sueldo Basico = Puntos Salariales Reconocidos x Valor Punto Salarial Vigente ($ 23.924 COP).");
            ImGui::BulletText("Factores Salariales: Titulos academicos (Doctorado, Maestria), Categoria (Titular, Asociado), Produccion Academica.");
            ImGui::BulletText("Bonificaciones especiales por posgrado e investigacion.");
            ImGui::Spacing();

            ImGui::TextColored(tema::WIN_BLUE(), "2. Profesores Ocasionales (Acuerdo 027 de 2024):");
            ImGui::BulletText("Vinculacion por periodo academico o meses laborados.");
            ImGui::BulletText("Pago proporcional al tiempo de dedicacion (Tiempo Completo / Medio Tiempo).");
            ImGui::BulletText("Factor salarial indexado a SMMLV ($ 1.750.905 COP, por ejemplo factor 2.92).");
            ImGui::Spacing();

            ImGui::TextColored(tema::WIN_BLUE(), "3. Profesores Catedraticos (Resolucion Rectoral):");
            ImGui::BulletText("Remuneracion basada en el valor de la Hora Catedra ($ 38.500 COP) por el numero de horas dictadas.");
            ImGui::Spacing();

            ImGui::TextColored(tema::WIN_BLUE(), "4. Descuentos Obligatorios de Ley:");
            ImGui::BulletText("Salud Trabajador: 4.0 %% del Ingreso Base de Cotizacion (IBC).");
            ImGui::BulletText("Pension Trabajador: 4.0 %% del Ingreso Base de Cotizacion (IBC).");
            ImGui::BulletText("Fondo de Solidaridad Pensional (FSP): 1.0 %% adicional cuando el IBC sea mayor o igual a 4 SMMLV ($ 7.003.620 COP).");
            ImGui::BulletText("Auxilio de Transporte: Aplica a docentes con ingreso inferior a 2 SMMLV ($ 249.095 COP).");
            ImGui::Spacing();

            ImGui::TextColored(tema::WIN_BLUE(), "5. Prestaciones Sociales Proyectadas:");
            ImGui::BulletText("Cesantias (8.33 %%), Intereses sobre Cesantias (1.0 %%), Prima de Servicios (8.33 %%) y Vacaciones (4.17 %%).");
            ImGui::EndChild();

            ImGui::EndTabItem();
        }

        ImGui::EndTabBar();
    }
}

// ======================================================================
// MODALES DE NÓMINA
// ======================================================================

void PITAApp::renderModalPeriodoNomina() {
    if (modalPeriodoNominaAbierto) {
        ImGui::OpenPopup("Gestion de Periodos de Nomina y Cierre Contable");
    }

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(740, 0), ImGuiCond_Always);

    if (ImGui::BeginPopupModal("Gestion de Periodos de Nomina y Cierre Contable", &modalPeriodoNominaAbierto, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (strlen(mensajeModal) > 0) {
            ImGui::TextColored(errorModal ? tema::ACCENT_DANGER() : tema::ACCENT_SUCCESS(), "%s", mensajeModal);
            ImGui::Separator();
        }

        ImGui::TextColored(tema::TEXT_MAIN(), "Periodos de Nomina Registrados");
        ImGui::TextColored(tema::TEXT_MUTED(), "Administracion de cortes mensuales, estado de auditoria contable y consolidacion de costos.");
        ImGui::Spacing();

        if (ImGui::BeginTable("##TablaPeriodosList", 6, ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg | ImGuiTableFlags_SizingStretchProp)) {
            ImGui::TableSetupColumn("ID", ImGuiTableColumnFlags_WidthFixed, 35.0f);
            ImGui::TableSetupColumn("Periodo", ImGuiTableColumnFlags_WidthFixed, 90.0f);
            ImGui::TableSetupColumn("Rango de Fechas", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupColumn("Estado", ImGuiTableColumnFlags_WidthFixed, 85.0f);
            ImGui::TableSetupColumn("Costo Acumulado", ImGuiTableColumnFlags_WidthStretch);
            ImGui::TableSetupColumn("Accion", ImGuiTableColumnFlags_WidthFixed, 120.0f);
            ImGui::TableHeadersRow();

            for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
                auto& p = ctrl.datos.periodosNomina.obtener(i);
                int pId = p.idPeriodoNomina.value_or(0);
                std::string perStr = std::to_string(p.anio.value_or(2026)) + "-" + ((p.mes.value_or(1) < 10) ? "0" : "") + std::to_string(p.mes.value_or(1));
                std::string rangoFechas = p.fechaInicio.value_or("") + " al " + p.fechaFin.value_or("");
                std::string est = p.estado.value_or("ABIERTO");
                bool cerrado = p.estaCerrado.value_or(false) || (est == "CERRADO");

                double costo = p.costoTotalPeriodo.value_or(0.0);
                if (costo <= 0.0) {
                    for (size_t li = 0; li < ctrl.datos.liquidacionesNomina.tamano(); ++li) {
                        auto& l = ctrl.datos.liquidacionesNomina.obtener(li);
                        if (l.idPeriodoNomina && *l.idPeriodoNomina == pId) {
                            costo += l.costoTotalEmpleador.value_or(l.totalDevengado.value_or(0.0));
                        }
                    }
                }

                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                ImGui::Text("%d", pId);

                ImGui::TableNextColumn();
                ImGui::TextColored(tema::TEXT_MAIN(), "%s", perStr.c_str());

                ImGui::TableNextColumn();
                ImGui::TextColored(tema::TEXT_MUTED(), "%s", rangoFechas.c_str());

                ImGui::TableNextColumn();
                if (!cerrado) {
                    ImGui::PushStyleColor(ImGuiCol_Button, tema::BADGE_ACTIVE_BG());
                    ImGui::PushStyleColor(ImGuiCol_Text, tema::BADGE_ACTIVE_TXT());
                    ImGui::SmallButton("ABIERTO");
                    ImGui::PopStyleColor(2);
                } else {
                    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.25f, 0.25f, 0.28f, 0.5f));
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.70f, 0.70f, 0.75f, 1.0f));
                    ImGui::SmallButton("CERRADO");
                    ImGui::PopStyleColor(2);
                }

                ImGui::TableNextColumn();
                ImGui::TextColored(tema::WIN_BLUE(), "%s", formatearMoneda(costo).c_str());

                ImGui::TableNextColumn();
                ImGui::PushID(static_cast<int>(i + 500));
                if (!cerrado) {
                    ImGui::PushStyleColor(ImGuiCol_Button, tema::ACCENT_DANGER());
                    if (ImGui::SmallButton("Cerrar Periodo")) {
                        try {
                            ctrl.gestorNomina->cerrarPeriodoNomina(pId);
                            ctrl.guardarDatos();
                            ctrl.setMensaje("Periodo de nomina cerrado y auditado con exito.");
                            strncpy(mensajeModal, "Periodo cerrado y auditado exitosamente.", sizeof(mensajeModal) - 1);
                            errorModal = false;
                        } catch (const std::exception& ex) {
                            strncpy(mensajeModal, ex.what(), sizeof(mensajeModal) - 1);
                            errorModal = true;
                        }
                    }
                    ImGui::PopStyleColor();
                } else {
                    ImGui::TextColored(tema::TEXT_MUTED(), "Auditado");
                }
                ImGui::PopID();
            }
            ImGui::EndTable();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        ImGui::TextColored(tema::TEXT_MAIN(), "Crear Nuevo Periodo Mensual:");
        ImGui::SetNextItemWidth(110);
        ImGui::InputInt("Ano *", &perAnio);
        ImGui::SameLine();
        ImGui::SetNextItemWidth(110);
        ImGui::InputInt("Mes (1-12) *", &perMes);
        if (perMes < 1) perMes = 1;
        if (perMes > 12) perMes = 12;

        ImGui::SameLine();
        if (ImGui::Button("Registrar Periodo", ImVec2(140, 0))) {
            try {
                ctrl.gestorNomina->cicloVida.crearPeriodoNominaMensual(perAnio, perMes);
                ctrl.guardarDatos();
                ctrl.setMensaje("Periodo de nomina registrado con exito.");
                strncpy(mensajeModal, "Nuevo periodo registrado exitosamente.", sizeof(mensajeModal) - 1);
                errorModal = false;
            } catch (const std::exception& e) {
                strncpy(mensajeModal, e.what(), sizeof(mensajeModal) - 1);
                errorModal = true;
            }
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::Button("Cerrar Ventana", ImVec2(140, 0))) {
            modalPeriodoNominaAbierto = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

void PITAApp::renderModalLiquidar() {
    if (modalLiquidarAbierto) {
        ImGui::OpenPopup("Liquidar Nomina");
    }

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(480, 0), ImGuiCond_Always);

    if (ImGui::BeginPopupModal("Liquidar Nomina", &modalLiquidarAbierto, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (strlen(mensajeModal) > 0) {
            ImGui::TextColored(errorModal ? tema::ACCENT_DANGER() : tema::ACCENT_SUCCESS(), "%s", mensajeModal);
            ImGui::Separator();
        }

        // Selector Periodo
        std::string previewPer = "Seleccione Periodo";
        for (int i = 0; i < ctrl.datos.periodosNomina.tamano(); i++) {
            auto& pn = ctrl.datos.periodosNomina.obtener(i);
            if (pn.idPeriodoNomina && *pn.idPeriodoNomina == liqPeriodoId) {
                previewPer = std::to_string(pn.anio.value_or(0)) + "-" + std::to_string(pn.mes.value_or(0));
                break;
            }
        }
        if (ImGui::BeginCombo("Periodo a Liquidar *", previewPer.c_str())) {
            for (int i = 0; i < ctrl.datos.periodosNomina.tamano(); i++) {
                auto& pn = ctrl.datos.periodosNomina.obtener(i);
                bool isSelected = (pn.idPeriodoNomina && *pn.idPeriodoNomina == liqPeriodoId);
                std::string label = "Periodo " + std::to_string(pn.anio.value_or(0)) + "-" + std::to_string(pn.mes.value_or(0)) + " [" + (pn.estado ? *pn.estado : "") + "]";
                if (ImGui::Selectable(label.c_str(), isSelected)) {
                    liqPeriodoId = pn.idPeriodoNomina.value_or(1);
                }
                if (isSelected) ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }

        // Selector Contrato (0: Todos)
        std::string previewCon = (liqContratoId == 0) ? "TODOS LOS CONTRATOS VIGENTES" : ("Contrato #" + std::to_string(liqContratoId));
        if (ImGui::BeginCombo("Alcance de Liquidacion", previewCon.c_str())) {
            if (ImGui::Selectable("TODOS LOS CONTRATOS VIGENTES", liqContratoId == 0)) {
                liqContratoId = 0;
            }
            for (int i = 0; i < ctrl.datos.contratos.tamano(); i++) {
                auto& c = ctrl.datos.contratos.obtener(i);
                if (c.idContrato && c.estado && *c.estado == "ACTIVO") {
                    bool isSelected = (*c.idContrato == liqContratoId);
                    std::string persNom = "";
                    if (c.idPersona) {
                        for (size_t j = 0; j < ctrl.datos.personas.tamano(); ++j) {
                            auto& p = ctrl.datos.personas.obtener(j);
                            if (p.idPersona && *p.idPersona == *c.idPersona) {
                                persNom = (p.primerNombre ? *p.primerNombre : "") + " " + (p.primerApellido ? *p.primerApellido : "");
                                break;
                            }
                        }
                    }
                    std::string label = "Contrato #" + std::to_string(*c.idContrato) + " - " + persNom + " (" + (c.tipoContrato ? *c.tipoContrato : "") + ")";
                    if (ImGui::Selectable(label.c_str(), isSelected)) {
                        liqContratoId = *c.idContrato;
                    }
                    if (isSelected) ImGui::SetItemDefaultFocus();
                }
            }
            ImGui::EndCombo();
        }

        ImGui::Spacing();
        ImGui::Separator();

        if (ImGui::Button("Ejecutar Liquidacion", ImVec2(160, 0))) {
            try {
                int liqGeneradas = 0;
                if (liqContratoId > 0) {
                    for (int i = 0; i < ctrl.datos.contratos.tamano(); i++) {
                        auto& c = ctrl.datos.contratos.obtener(i);
                        if (c.idContrato && *c.idContrato == liqContratoId) {
                            if (c.tipoContrato && *c.tipoContrato == "DOCENTE_PLANTA") {
                                ctrl.gestorNomina->liquidarProfesorPlanta(liqContratoId, liqPeriodoId);
                            } else if (c.tipoContrato && *c.tipoContrato == "DOCENTE_OCASIONAL") {
                                ctrl.gestorNomina->liquidarProfesorOcasional(liqContratoId, liqPeriodoId);
                            } else if (c.tipoContrato && (*c.tipoContrato == "ADMINISTRATIVO" || *c.tipoContrato == "PERSONAL_ADMINISTRATIVO")) {
                                ctrl.gestorNomina->liquidarAdministrativo(liqContratoId, liqPeriodoId);
                            } else {
                                ctrl.gestorNomina->liquidarProfesorCatedratico(liqContratoId, liqPeriodoId);
                            }
                            liqGeneradas++;
                            break;
                        }
                    }
                } else {
                    for (int i = 0; i < ctrl.datos.contratos.tamano(); i++) {
                        auto& c = ctrl.datos.contratos.obtener(i);
                        if (c.idContrato && c.estado && *c.estado == "ACTIVO") {
                            try {
                                if (c.tipoContrato && *c.tipoContrato == "DOCENTE_PLANTA") {
                                    ctrl.gestorNomina->liquidarProfesorPlanta(*c.idContrato, liqPeriodoId);
                                } else if (c.tipoContrato && *c.tipoContrato == "DOCENTE_OCASIONAL") {
                                    ctrl.gestorNomina->liquidarProfesorOcasional(*c.idContrato, liqPeriodoId);
                                } else if (c.tipoContrato && (*c.tipoContrato == "ADMINISTRATIVO" || *c.tipoContrato == "PERSONAL_ADMINISTRATIVO")) {
                                    ctrl.gestorNomina->liquidarAdministrativo(*c.idContrato, liqPeriodoId);
                                } else {
                                    ctrl.gestorNomina->liquidarProfesorCatedratico(*c.idContrato, liqPeriodoId);
                                }
                                liqGeneradas++;
                            } catch (...) {}
                        }
                    }
                }

                ctrl.guardarDatos();
                ctrl.setMensaje("Liquidacion procesada exitosamente (" + std::to_string(liqGeneradas) + " contratos calculados).");
                modalLiquidarAbierto = false;
                ImGui::CloseCurrentPopup();
            } catch (const std::exception& e) {
                strncpy(mensajeModal, e.what(), sizeof(mensajeModal) - 1);
                errorModal = true;
            }
        }

        ImGui::SameLine();
        if (ImGui::Button("Cancelar", ImVec2(120, 0))) {
            modalLiquidarAbierto = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

void PITAApp::renderModalPagarNomina() {
    if (modalPagarNominaAbierto) {
        ImGui::OpenPopup("Pagar Liquidacion");
    }

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(440, 0), ImGuiCond_Always);

    if (ImGui::BeginPopupModal("Pagar Liquidacion", &modalPagarNominaAbierto, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (strlen(mensajeModal) > 0) {
            ImGui::TextColored(errorModal ? tema::ACCENT_DANGER() : tema::ACCENT_SUCCESS(), "%s", mensajeModal);
            ImGui::Separator();
        }

        ImGui::Text("Pagando Liquidacion ID: %d", idLiquidacionPagando);
        ImGui::Spacing();

        const char* medios[] = { "TRANSFERENCIA_BANCARIA", "CHEQUE", "CONSIGNACION" };
        static int medioIdx = 0;
        if (ImGui::Combo("Medio de Pago", &medioIdx, medios, IM_ARRAYSIZE(medios))) {
            strncpy(pagMedio, medios[medioIdx], sizeof(pagMedio) - 1);
        }

        ImGui::InputText("Referencia / Comprobante *", pagReferencia, sizeof(pagReferencia));

        ImGui::Spacing();
        ImGui::Separator();

        if (ImGui::Button("Registrar Pago", ImVec2(140, 0))) {
            try {
                ctrl.gestorNomina->cicloVida.pagarLiquidacion(idLiquidacionPagando, pagMedio, pagReferencia);
                ctrl.guardarDatos();
                ctrl.setMensaje("Pago registrado y liquidacion cerrada.");
                modalPagarNominaAbierto = false;
                ImGui::CloseCurrentPopup();
            } catch (const std::exception& e) {
                strncpy(mensajeModal, e.what(), sizeof(mensajeModal) - 1);
                errorModal = true;
            }
        }

        ImGui::SameLine();
        if (ImGui::Button("Cancelar", ImVec2(120, 0))) {
            modalPagarNominaAbierto = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

// ----------------------------------------------------------------------
// MODAL DESPRENDIBLE DE LIQUIDACIÓN
// ----------------------------------------------------------------------
void PITAApp::renderModalDesprendible() {
    if (modalDesprendibleAbierto) {
        ImGui::OpenPopup("Desprendible de Liquidacion");
    }

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(660, 720), ImGuiCond_Always);

    if (ImGui::BeginPopupModal("Desprendible de Liquidacion", &modalDesprendibleAbierto, ImGuiWindowFlags_None)) {
        LiquidacionNomina* liqPtr = nullptr;
        for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
            auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
            if (l.idLiquidacion && *l.idLiquidacion == idLiquidacionDesprendible) {
                liqPtr = &l;
                break;
            }
        }

        if (!liqPtr) {
            ImGui::TextColored(tema::ACCENT_DANGER(), "No se encontro la liquidacion seleccionada.");
            if (ImGui::Button("Cerrar", ImVec2(120, 0))) {
                modalDesprendibleAbierto = false;
                ImGui::CloseCurrentPopup();
            }
            ImGui::EndPopup();
            return;
        }

        bool esAdmin = (!liqPtr->idProfesor.has_value() || *liqPtr->idProfesor == 0 ||
                        (liqPtr->regimenLiquidado && liqPtr->regimenLiquidado->find("ADMINISTRATIVO") != std::string::npos));

        const Contrato* conLiq = nullptr;
        if (liqPtr->idContrato) {
            for (size_t i = 0; i < ctrl.datos.contratos.tamano(); ++i) {
                if (ctrl.datos.contratos.obtener(i).idContrato == liqPtr->idContrato) {
                    conLiq = &ctrl.datos.contratos.obtener(i);
                    break;
                }
            }
        }
        const Administrativo* admPtr = nullptr;
        std::string nomEmpleado = "";
        std::string cargoEmp = liqPtr->categoriaLiquidada.value_or("ADMINISTRATIVO");
        std::string dependenciaEmp = "Administracion Central";
        std::string tipoContratoStr = (conLiq && conLiq->tipoContrato) ? *conLiq->tipoContrato : "TERMINO_INDEFINIDO";

        int idProf = liqPtr->idProfesor.value_or(0);
        std::string tipoDocente = liqPtr->tipoProfesorLiquidado ? to_string(*liqPtr->tipoProfesorLiquidado) : "PLANTA";

        const Profesor* profPtr = nullptr;
        if (!esAdmin) {
            nomEmpleado = getNombreDocente(ctrl, idProf);
            for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
                auto& p = ctrl.datos.profesores.obtener(i);
                if (p.idProfesor && *p.idProfesor == idProf) {
                    profPtr = &p;
                    break;
                }
            }
        } else {
            nomEmpleado = getNombreEmpleado(ctrl, *liqPtr);
            if (conLiq) {
                for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
                    auto& a = ctrl.datos.administrativos.obtener(i);
                    if (a.idPersona == conLiq->idPersona) {
                        admPtr = &a;
                        break;
                    }
                }
            }
            if (admPtr) {
                if (admPtr->cargo) cargoEmp = *admPtr->cargo;
                if (admPtr->dependencia) dependenciaEmp = *admPtr->dependencia;
            }
            if (nomEmpleado.empty()) nomEmpleado = "Funcionario Administrativo";
        }

        const PeriodoNomina* periodoPtr = nullptr;
        int idPer = liqPtr->idPeriodoNomina.value_or(0);
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == idPer) {
                periodoPtr = &p;
                break;
            }
        }

        static const char* MESES_ES[] = { "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" };
        std::string txtPeriodo = "Periodo N° " + std::to_string(idPer);
        if (periodoPtr && periodoPtr->mes && periodoPtr->anio) {
            int m = *periodoPtr->mes;
            int a = *periodoPtr->anio;
            std::string nomMes = (m >= 1 && m <= 12) ? MESES_ES[m] : ("Mes " + std::to_string(m));
            txtPeriodo = nomMes + " " + std::to_string(a);
            if (periodoPtr->fechaInicio && periodoPtr->fechaFin) {
                txtPeriodo += " (" + *periodoPtr->fechaInicio + " - " + *periodoPtr->fechaFin + ")";
            }
        }

        // Puntos salariales, valor punto e IBC
        double puntosTotales = liqPtr->puntosSalarialesUsados.value_or(0.0);
        if (puntosTotales <= 0.0 && profPtr && profPtr->puntosSalariales) {
            puntosTotales = *profPtr->puntosSalariales;
        }

        double valorPto = liqPtr->valorPuntoUsado.value_or(0.0);
        if (valorPto <= 0.0) {
            for (size_t i = 0; i < ctrl.datos.parametrosNormativos.tamano(); ++i) {
                auto& param = ctrl.datos.parametrosNormativos.obtener(i);
                if (param.codigo && *param.codigo == ParametroNormativoCodigo::VALOR_PUNTO_SALARIAL) {
                    if (param.valor) {
                        try { valorPto = std::stod(*param.valor); } catch (...) {}
                    }
                    break;
                }
            }
        }
        if (valorPto <= 0.0) valorPto = 23924.0;

        double ibcVal = liqPtr->baseCotizacionSeguridadSocial.value_or(
            liqPtr->salarioBase.value_or(liqPtr->totalDevengado.value_or(0.0)));

        std::string labelAsignacion = "Asignacion Basica Mensual";
        if (tipoDocente == "PLANTA" && puntosTotales > 0) {
            char bufAsig[128];
            snprintf(bufAsig, sizeof(bufAsig), "Asignacion Basica Mensual (%.0f pts x %s)", puntosTotales, formatearMoneda(valorPto).c_str());
            labelAsignacion = bufAsig;
        } else if (tipoDocente == "PLANTA") {
            labelAsignacion = "Asignacion Basica Mensual (Dec. 1279)";
        } else {
            labelAsignacion = "Sueldo Basico Ordinario";
        }

        // Cabecera informativa estilo tarjeta
        ImGui::BeginChild("##HeaderCardDesprendible", ImVec2(0, 85), true);
        if (fuenteTitulo) ImGui::PushFont(fuenteTitulo);
        ImGui::TextColored(tema::TEXT_MAIN(), "Desprendible Oficial de Pago de Nomina");
        if (fuenteTitulo) ImGui::PopFont();
        if (esAdmin) {
            ImGui::TextColored(tema::TEXT_MUTED(), "Funcionario: %s  |  Cargo: %s  |  Liquidacion N° %d",
                nomEmpleado.c_str(), cargoEmp.c_str(), idLiquidacionDesprendible);
        } else {
            ImGui::TextColored(tema::TEXT_MUTED(), "Docente: %s  |  Modalidad: %s  |  Liquidacion N° %d",
                nomEmpleado.c_str(), tipoDocente.c_str(), idLiquidacionDesprendible);
        }
        ImGui::TextColored(tema::WIN_BLUE(), "Periodo Liquidado: %s", txtPeriodo.c_str());
        ImGui::EndChild();

        ImGui::Spacing();

        // Categorías de conceptos
        struct ConceptoItem {
            std::string nombre;
            std::string tipo;
            double valor;
        };

        std::vector<ConceptoItem> devengados;
        std::vector<ConceptoItem> deducciones;
        std::vector<ConceptoItem> patronales;

        // Buscar en detallesLiquidacion
        for (size_t i = 0; i < ctrl.datos.detallesLiquidacion.tamano(); ++i) {
            auto& d = ctrl.datos.detallesLiquidacion.obtener(i);
            if (d.idLiquidacion && *d.idLiquidacion == idLiquidacionDesprendible) {
                std::string tm = d.tipoMovimiento.value_or("");
                std::string obs = d.observaciones.value_or("");
                double val = d.valorCalculado.value_or(0.0);

                std::string tmUpper = tm;
                for (auto& c : tmUpper) c = static_cast<char>(toupper(c));
                std::string obsLower = obs;
                for (auto& c : obsLower) c = static_cast<char>(tolower(c));

                bool esDed = (tmUpper.find("DESCUENTO") != std::string::npos ||
                              tmUpper.find("DED") != std::string::npos ||
                              tmUpper == "FONDO_SOLIDARIDAD" || tmUpper == "RETENCION_FUENTE" ||
                              obsLower.find("salud") != std::string::npos || obsLower.find("pension") != std::string::npos ||
                              obsLower.find("fsp") != std::string::npos || obsLower.find("retencion") != std::string::npos);

                if (tmUpper.find("APORTE") != std::string::npos || tmUpper.find("PATRONAL") != std::string::npos || obsLower.find("patronal") != std::string::npos) {
                    esDed = false;
                }

                bool esPat = (tmUpper.find("APORTE") != std::string::npos || tmUpper.find("PATRONAL") != std::string::npos ||
                              obsLower.find("patronal") != std::string::npos || obsLower.find("arl") != std::string::npos ||
                              obsLower.find("sena") != std::string::npos || obsLower.find("icbf") != std::string::npos ||
                              obsLower.find("caja") != std::string::npos);

                std::string label = tm;
                if (tmUpper == "SALARIO_ORDINARIO") {
                    label = labelAsignacion;
                } else if (tmUpper == "AUXILIO_TRANSPORTE") {
                    label = "Auxilio Legal de Transporte";
                } else if (tmUpper == "BONIFICACION_POSGRADO") {
                    label = "Bonificacion por Posgrado (Dec. 1279)";
                } else if (tmUpper == "BONIFICACION_INVESTIGACION") {
                    label = "Bonificacion por Investigacion";
                } else if (tmUpper == "DESCUENTO_SALUD") {
                    label = "Aporte Salud Trabajador (4%)";
                } else if (tmUpper == "DESCUENTO_PENSION") {
                    label = "Aporte Pension Trabajador (4%)";
                } else if (tmUpper == "FONDO_SOLIDARIDAD") {
                    label = "Fondo de Solidaridad Pensional (1%)";
                } else if (tmUpper == "RETENCION_FUENTE") {
                    label = "Retencion en la Fuente";
                } else if (tmUpper == "DESCUENTO_INCUMPLIMIENTO") {
                    label = "Descuento por Horas Incumplidas";
                } else if (tmUpper == "APORTE_SALUD_PATRONAL") {
                    label = "Salud Patronal (8.5%)";
                } else if (tmUpper == "APORTE_PENSION_PATRONAL") {
                    label = "Pension Patronal (12%)";
                } else if (tmUpper == "APORTE_ARL") {
                    label = "Aporte Riesgos Laborales (ARL)";
                } else if (tmUpper == "APORTE_CAJA") {
                    label = "Caja de Compensacion Familiar (4%)";
                } else if (tmUpper == "APORTE_SENA") {
                    label = "Aporte Parafiscal SENA (2%)";
                } else if (tmUpper == "APORTE_ICBF") {
                    label = "Aporte Parafiscal ICBF (3%)";
                } else if (!obs.empty()) {
                    label = obs;
                }

                // Omitir conceptos en 0 que no sean el salario ordinario
                if (val == 0.0 && tmUpper != "SALARIO_ORDINARIO" && tmUpper != "SUELDO") {
                    continue;
                }

                if (esDed) {
                    deducciones.push_back({ label, tm, val });
                } else if (esPat) {
                    patronales.push_back({ label, tm, val });
                } else {
                    devengados.push_back({ label, tm, val });
                }
            }
        }

        // Si no había detalles, reconstruir con la fórmula fiel de Python
        if (devengados.empty() && deducciones.empty()) {
            double sb = liqPtr->salarioBase.value_or(0.0);
            double dev = liqPtr->totalDevengado.value_or(sb);
            double desc = liqPtr->totalDescuentos.value_or(0.0);

            if (tipoDocente == "PLANTA") {
                devengados.push_back({ labelAsignacion, "SALARIO_ORDINARIO", sb });
            } else {
                devengados.push_back({ "Sueldo Basico Mensual", "SALARIO_ORDINARIO", sb });
            }
            if (dev > sb) {
                devengados.push_back({ "Auxilio Legal de Transporte / Bonificaciones", "AUXILIO", dev - sb });
            }

            double salud = std::round(sb * 0.04);
            double pension = std::round(sb * 0.04);
            deducciones.push_back({ "Aporte Salud Trabajador (4%)", "DESCUENTO_SALUD", salud });
            deducciones.push_back({ "Aporte Pension Trabajador (4%)", "DESCUENTO_PENSION", pension });

            double restoDesc = desc - (salud + pension);
            if (restoDesc > 0) {
                deducciones.push_back({ "Fondo de Solidaridad Pensional (1%)", "RETENCION", restoDesc });
            }

            patronales.push_back({ "Salud Patronal (8.5%)", "APORTE_SALUD_PATRONAL", std::round(dev * 0.085) });
            patronales.push_back({ "Pension Patronal (12%)", "APORTE_PENSION_PATRONAL", std::round(dev * 0.12) });
            patronales.push_back({ "Aporte Riesgos Laborales (ARL)", "APORTE_ARL", std::round(dev * 0.00522) });
            patronales.push_back({ "Caja de Compensacion Familiar (4%)", "APORTE_CAJA", std::round(dev * 0.04) });
            patronales.push_back({ "Aporte Parafiscal SENA (2%)", "APORTE_SENA", std::round(dev * 0.02) });
            patronales.push_back({ "Aporte Parafiscal ICBF (3%)", "APORTE_ICBF", std::round(dev * 0.03) });
        }

        // Área scrolleable para las secciones
        ImGui::BeginChild("##ScrollDetalleSecciones", ImVec2(0, 445), false);

        auto renderSeccion = [](const char* titulo, const std::vector<ConceptoItem>& items, ImVec4 colorTitulo, bool esDeduccion, double ibc = 0.0) {
            if (items.empty()) return;

            ImGui::Spacing();
            ImGui::TextColored(colorTitulo, "%s", titulo);
            ImGui::Separator();

            if (esDeduccion && ibc > 0.0) {
                ImGui::TextColored(tema::TEXT_MUTED(), "  IBC Seguridad Social (Base Cotizacion):");
                ImGui::SameLine(ImGui::GetWindowWidth() - 180);
                ImGui::TextColored(tema::TEXT_MAIN(), "%s", formatearMoneda(ibc).c_str());
                ImGui::Separator();
            }

            for (const auto& item : items) {
                ImGui::Text("  %s", item.nombre.c_str());
                ImGui::SameLine(ImGui::GetWindowWidth() - 180);
                std::string signo = esDeduccion ? "- " : "+ ";
                ImVec4 colorVal = esDeduccion ? tema::ACCENT_DANGER() : tema::WIN_BLUE();
                ImGui::TextColored(colorVal, "%s%s", signo.c_str(), formatearMoneda(item.valor).c_str());
            }
            ImGui::Spacing();
        };

        // 1. Devengados
        renderSeccion("DEVENGADOS Y ASIGNACIONES (+)", devengados, tema::WIN_BLUE(), false);

        // 2. Deducciones de Ley
        renderSeccion("DEDUCCIONES OBLIGATORIAS DE LEY (-)", deducciones, tema::ACCENT_DANGER(), true, ibcVal);

        // 3. Costo Total Empleador (UPC)
        double devVal = liqPtr->totalDevengado.value_or(liqPtr->salarioBase.value_or(0.0));
        double sumaPatronal = 0.0;
        for (const auto& item : patronales) {
            sumaPatronal += item.valor;
        }
        double totalCostoUPC = devVal + sumaPatronal;

        ImGui::Spacing();
        ImGui::TextColored(tema::ACCENT_WARNING(), "COSTO TOTAL EMPLEADOR (UNIVERSIDAD POPULAR DEL CESAR)");
        ImGui::Separator();

        ImGui::Text("  Asignacion Basica");
        ImGui::SameLine(ImGui::GetWindowWidth() - 180);
        ImGui::TextColored(tema::TEXT_MAIN(), "%s", formatearMoneda(devVal).c_str());

        for (const auto& item : patronales) {
            ImGui::Text("  %s", item.nombre.c_str());
            ImGui::SameLine(ImGui::GetWindowWidth() - 180);
            ImGui::TextColored(tema::TEXT_MUTED(), "%s", formatearMoneda(item.valor).c_str());
        }

        ImGui::Separator();
        ImGui::TextColored(tema::TEXT_MAIN(), "  TOTAL COSTO UPC");
        ImGui::SameLine(ImGui::GetWindowWidth() - 180);
        ImGui::TextColored(tema::WIN_BLUE(), "%s", formatearMoneda(totalCostoUPC).c_str());
        ImGui::Spacing();

        // 4. Información Salarial Docente o Laboral Administrativa
        if (esAdmin) {
            ImGui::Spacing();
            ImGui::TextColored(tema::WIN_BLUE(), "INFORMACION LABORAL Y SALARIAL (CST / LEY 100)");
            ImGui::Separator();

            ImGui::Text("  Cargo Institucional:");
            ImGui::SameLine(ImGui::GetWindowWidth() - 240);
            ImGui::TextColored(tema::TEXT_MAIN(), "%s", cargoEmp.c_str());

            ImGui::Text("  Dependencia Adscrita:");
            ImGui::SameLine(ImGui::GetWindowWidth() - 240);
            ImGui::TextColored(tema::TEXT_MAIN(), "%s", dependenciaEmp.c_str());

            ImGui::Text("  Tipo de Contratacion:");
            ImGui::SameLine(ImGui::GetWindowWidth() - 240);
            ImGui::TextColored(tema::TEXT_MAIN(), "%s", tipoContratoStr.c_str());

            ImGui::Text("  Sueldo Basico Ordinario:");
            ImGui::SameLine(ImGui::GetWindowWidth() - 240);
            double sBase = liqPtr->salarioBase.value_or(0.0);
            ImGui::TextColored(tema::TEXT_MAIN(), "%s", formatearMoneda(sBase).c_str());

            ImGui::Text("  IBC Seguridad Social:");
            ImGui::SameLine(ImGui::GetWindowWidth() - 240);
            ImGui::TextColored(tema::WIN_BLUE(), "%s", formatearMoneda(ibcVal).c_str());
            ImGui::Spacing();
        } else {
            std::string categoriaDoc = liqPtr->categoriaLiquidada.value_or("");
            if (categoriaDoc.empty() && profPtr && profPtr->categoriaDocente) {
                categoriaDoc = *profPtr->categoriaDocente;
            }
            if (categoriaDoc.empty()) {
                categoriaDoc = (tipoDocente == "PLANTA") ? "Titular" : "Docente Catedra";
            }

            ImGui::Spacing();
            ImGui::TextColored(tema::WIN_BLUE(), "INFORMACION SALARIAL DOCENTE (DECRETO 1279)");
            ImGui::Separator();

            ImGui::Text("  Categoria Docente:");
            ImGui::SameLine(ImGui::GetWindowWidth() - 240);
            ImGui::TextColored(tema::TEXT_MAIN(), "%s", categoriaDoc.c_str());

            if (puntosTotales > 0.0 || tipoDocente == "PLANTA") {
                ImGui::Text("  Total Puntos Salariales:");
                ImGui::SameLine(ImGui::GetWindowWidth() - 240);
                ImGui::TextColored(tema::TEXT_MAIN(), "%.0f pts", puntosTotales);

                ImGui::Text("  Valor Punto Salarial:");
                ImGui::SameLine(ImGui::GetWindowWidth() - 240);
                ImGui::TextColored(tema::TEXT_MAIN(), "%s", formatearMoneda(valorPto).c_str());

                char bufCalculo[128];
                snprintf(bufCalculo, sizeof(bufCalculo), "%.0f pts x %s", puntosTotales, formatearMoneda(valorPto).c_str());
                ImGui::Text("  Calculo Asignacion Basica:");
                ImGui::SameLine(ImGui::GetWindowWidth() - 240);
                ImGui::TextColored(tema::WIN_BLUE(), "%s", bufCalculo);

                ImGui::Text("  IBC Seguridad Social:");
                ImGui::SameLine(ImGui::GetWindowWidth() - 240);
                ImGui::TextColored(tema::TEXT_MAIN(), "%s", formatearMoneda(ibcVal).c_str());
            } else {
                ImGui::Text("  Modalidad Vinculacion:");
                ImGui::SameLine(ImGui::GetWindowWidth() - 240);
                ImGui::TextColored(tema::TEXT_MAIN(), "%s", tipoDocente.c_str());

                ImGui::Text("  IBC Seguridad Social:");
                ImGui::SameLine(ImGui::GetWindowWidth() - 240);
                ImGui::TextColored(tema::TEXT_MAIN(), "%s", formatearMoneda(ibcVal).c_str());
            }
            ImGui::Spacing();
        }

        ImGui::EndChild();

        ImGui::Separator();
        ImGui::Spacing();

        // Tarjeta final de Neto a Pagar enmarcada
        double netoVal = liqPtr->netoPagar.value_or(0.0);
        double descVal = liqPtr->totalDescuentos.value_or(0.0);

        ImGui::BeginChild("##CardNetoFinal", ImVec2(0, 64), true);
        ImGui::TextColored(tema::TEXT_MAIN(), "NETO A PAGAR:");
        ImGui::SameLine(ImGui::GetWindowWidth() - 220);
        ImGui::TextColored(ImVec4(0.063f, 0.725f, 0.506f, 1.0f), "%s", formatearMoneda(netoVal).c_str());
        ImGui::TextColored(tema::TEXT_MUTED(), "Total Devengado: %s  ·  Total Deducciones: -%s",
            formatearMoneda(devVal).c_str(), formatearMoneda(descVal).c_str());
        ImGui::EndChild();

        ImGui::Spacing();
        bool perCerradoLiq = false;
        if (liqPtr->idPeriodoNomina) {
            for (size_t pidx = 0; pidx < ctrl.datos.periodosNomina.tamano(); ++pidx) {
                auto& pcheck = ctrl.datos.periodosNomina.obtener(pidx);
                if (pcheck.idPeriodoNomina && *pcheck.idPeriodoNomina == *liqPtr->idPeriodoNomina) {
                    perCerradoLiq = pcheck.estaCerrado.value_or(false) || (pcheck.estado && *pcheck.estado == "CERRADO");
                    break;
                }
            }
        }
        bool pagadaLiq = liqPtr->pagada.value_or(false) || (liqPtr->estado && *liqPtr->estado == "PAGADA");
        if (!perCerradoLiq && !pagadaLiq) {
            ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.47f, 0.05f, 0.85f));
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
            if (ImGui::Button("Reliquidar Nomina", ImVec2(160, 32))) {
                try {
                    ctrl.gestorNomina->cicloVida.reliquidar(idLiquidacionDesprendible);
                    ctrl.guardarDatos();
                } catch (...) {}
                modalDesprendibleAbierto = false;
                ImGui::CloseCurrentPopup();
            }
            ImGui::PopStyleColor(2);
            ImGui::SameLine();
        }
        if (ImGui::Button("Cerrar Desprendible", ImVec2(160, 32))) {
            modalDesprendibleAbierto = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

// ----------------------------------------------------------------------
// MODAL LIQUIDAR EMPLEADO INDIVIDUAL (DOCENTE / ADMINISTRATIVO)
// ----------------------------------------------------------------------
void PITAApp::renderModalLiquidarIndividual() {
    if (modalLiquidarIndividualAbierto) {
        ImGui::OpenPopup("👤 Liquidacion Individual de Empleado");
    }

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(540, 390), ImGuiCond_Always);

    if (ImGui::BeginPopupModal("👤 Liquidacion Individual de Empleado", &modalLiquidarIndividualAbierto, ImGuiWindowFlags_AlwaysAutoResize)) {
        if (strlen(mensajeModal) > 0) {
            ImGui::TextColored(errorModal ? tema::ACCENT_DANGER() : tema::ACCENT_SUCCESS(), "%s", mensajeModal);
            ImGui::Separator();
        }

        // Inicialización de período abierto por defecto si no está seteado
        if (idPeriodoLiquidarIndividual == 0) {
            if (nomFiltroPeriodoId > 0) {
                for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
                    auto& p = ctrl.datos.periodosNomina.obtener(i);
                    if (p.idPeriodoNomina && *p.idPeriodoNomina == nomFiltroPeriodoId) {
                        bool cerrado = p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO");
                        if (!cerrado) idPeriodoLiquidarIndividual = *p.idPeriodoNomina;
                        break;
                    }
                }
            }
            if (idPeriodoLiquidarIndividual == 0) {
                for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
                    auto& p = ctrl.datos.periodosNomina.obtener(i);
                    bool cerrado = p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO");
                    if (!cerrado && p.idPeriodoNomina) {
                        idPeriodoLiquidarIndividual = *p.idPeriodoNomina;
                        break;
                    }
                }
            }
            if (idPeriodoLiquidarIndividual == 0 && ctrl.datos.periodosNomina.tamano() > 0) {
                idPeriodoLiquidarIndividual = ctrl.datos.periodosNomina.obtener(0).idPeriodoNomina.value_or(1);
            }
        }

        // 1. Selector de Período de Nómina Destino
        ImGui::TextColored(tema::TEXT_MUTED(), "Periodo de Nomina Destino (Abierto):");
        std::string previewPer = "Seleccione un periodo...";
        bool periodoCerrado = false;
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == idPeriodoLiquidarIndividual) {
                bool cerrado = p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO");
                periodoCerrado = cerrado;
                previewPer = "#" + std::to_string(*p.idPeriodoNomina) + " - " +
                             std::to_string(p.anio.value_or(2026)) + "-" + std::to_string(p.mes.value_or(1)) +
                             (cerrado ? " [🔒 CERRADO]" : " [✅ ABIERTO]");
                break;
            }
        }

        ImGui::SetNextItemWidth(500);
        if (ImGui::BeginCombo("##ComboPeriodoLiqIndiv", previewPer.c_str())) {
            for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
                auto& p = ctrl.datos.periodosNomina.obtener(i);
                if (!p.idPeriodoNomina) continue;
                int pid = *p.idPeriodoNomina;
                bool isSel = (pid == idPeriodoLiquidarIndividual);
                bool cerrado = p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO");
                std::string lbl = "#" + std::to_string(pid) + " - " +
                                  std::to_string(p.anio.value_or(2026)) + "-" + std::to_string(p.mes.value_or(1)) +
                                  (cerrado ? " [🔒 CERRADO]" : " [✅ ABIERTO]");
                if (ImGui::Selectable(lbl.c_str(), isSel)) {
                    idPeriodoLiquidarIndividual = pid;
                }
                if (isSel) ImGui::SetItemDefaultFocus();
            }
            ImGui::EndCombo();
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // 2. Selector de Tipo de Personal
        ImGui::TextColored(tema::TEXT_MUTED(), "Tipo de Personal a Liquidar:");
        ImGui::RadioButton("Docente", &liqIndTipoPersonalIdx, 0);
        ImGui::SameLine(160);
        ImGui::RadioButton("Administrativo", &liqIndTipoPersonalIdx, 1);

        ImGui::Spacing();

        // 3. Selector de Empleado y Detección de Contrato
        bool tieneContratoActivo = false;

        if (liqIndTipoPersonalIdx == 0) {
            // DOCENTE
            if (idProfesorLiquidarIndividual == 0 && ctrl.datos.profesores.tamano() > 0) {
                idProfesorLiquidarIndividual = ctrl.datos.profesores.obtener(0).idProfesor.value_or(0);
            }

            if (idProfesorLiquidarIndividual > 0) {
                for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
                    auto& p = ctrl.datos.profesores.obtener(i);
                    if (p.idProfesor && *p.idProfesor == idProfesorLiquidarIndividual && p.idPersona) {
                        for (size_t c = 0; c < ctrl.datos.contratos.tamano(); ++c) {
                            auto& con = ctrl.datos.contratos.obtener(c);
                            if (con.idPersona == p.idPersona && con.estado && *con.estado == "ACTIVO") {
                                tieneContratoActivo = true;
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            std::string previewProf = "Seleccione un docente...";
            for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
                auto& p = ctrl.datos.profesores.obtener(i);
                if (p.idProfesor && *p.idProfesor == idProfesorLiquidarIndividual) {
                    previewProf = (p.codigoProfesor ? *p.codigoProfesor : "") + " - " + getNombreDocente(ctrl, *p.idProfesor) +
                                  (tieneContratoActivo ? " [✅ Contrato Activo]" : " [⚠️ Sin Contrato]");
                    break;
                }
            }

            ImGui::TextColored(tema::TEXT_MAIN(), "Seleccionar Docente:");
            ImGui::SetNextItemWidth(500);
            if (ImGui::BeginCombo("##ComboDocenteLiqIndiv", previewProf.c_str())) {
                for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
                    auto& p = ctrl.datos.profesores.obtener(i);
                    int profId = p.idProfesor.value_or(0);
                    bool isSelected = (profId == idProfesorLiquidarIndividual);
                    bool hasCon = false;
                    if (p.idPersona) {
                        for (size_t c = 0; c < ctrl.datos.contratos.tamano(); ++c) {
                            auto& con = ctrl.datos.contratos.obtener(c);
                            if (con.idPersona == p.idPersona && con.estado && *con.estado == "ACTIVO") {
                                hasCon = true;
                                break;
                            }
                        }
                    }
                    std::string label = (p.codigoProfesor ? *p.codigoProfesor : "") + " - " + getNombreDocente(ctrl, profId) +
                                      (hasCon ? " [✅ Contrato Activo]" : " [⚠️ Sin Contrato]");
                    if (ImGui::Selectable(label.c_str(), isSelected)) {
                        idProfesorLiquidarIndividual = profId;
                    }
                    if (isSelected) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
        } else {
            // ADMINISTRATIVO
            if (idAdminLiquidarIndividual == 0 && ctrl.datos.administrativos.tamano() > 0) {
                idAdminLiquidarIndividual = ctrl.datos.administrativos.obtener(0).idAdministrativo.value_or(0);
            }

            if (idAdminLiquidarIndividual > 0) {
                for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
                    auto& a = ctrl.datos.administrativos.obtener(i);
                    if (a.idAdministrativo && *a.idAdministrativo == idAdminLiquidarIndividual && a.idPersona) {
                        for (size_t c = 0; c < ctrl.datos.contratos.tamano(); ++c) {
                            auto& con = ctrl.datos.contratos.obtener(c);
                            if (con.idPersona == a.idPersona && con.estado && *con.estado == "ACTIVO") {
                                tieneContratoActivo = true;
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            std::string previewAdmin = "Seleccione un funcionario...";
            for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
                auto& a = ctrl.datos.administrativos.obtener(i);
                if (a.idAdministrativo && *a.idAdministrativo == idAdminLiquidarIndividual) {
                    previewAdmin = (a.codigoEmpleado ? *a.codigoEmpleado : ("ADM-" + std::to_string(*a.idAdministrativo))) + " - " +
                                  getNombreAdministrativo(ctrl, *a.idAdministrativo) + " (" + (a.cargo ? *a.cargo : "Cargo") + ")" +
                                  (tieneContratoActivo ? " [✅ Contrato Activo]" : " [⚠️ Sin Contrato]");
                    break;
                }
            }

            ImGui::TextColored(tema::TEXT_MAIN(), "Seleccionar Administrativo:");
            ImGui::SetNextItemWidth(500);
            if (ImGui::BeginCombo("##ComboAdminLiqIndiv", previewAdmin.c_str())) {
                for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
                    auto& a = ctrl.datos.administrativos.obtener(i);
                    int admId = a.idAdministrativo.value_or(0);
                    bool isSelected = (admId == idAdminLiquidarIndividual);
                    bool hasCon = false;
                    if (a.idPersona) {
                        for (size_t c = 0; c < ctrl.datos.contratos.tamano(); ++c) {
                            auto& con = ctrl.datos.contratos.obtener(c);
                            if (con.idPersona == a.idPersona && con.estado && *con.estado == "ACTIVO") {
                                hasCon = true;
                                break;
                            }
                        }
                    }
                    std::string label = (a.codigoEmpleado ? *a.codigoEmpleado : ("ADM-" + std::to_string(admId))) + " - " +
                                      getNombreAdministrativo(ctrl, admId) + " (" + (a.cargo ? *a.cargo : "Cargo") + ")" +
                                      (hasCon ? " [✅ Contrato Activo]" : " [⚠️ Sin Contrato]");
                    if (ImGui::Selectable(label.c_str(), isSelected)) {
                        idAdminLiquidarIndividual = admId;
                    }
                    if (isSelected) ImGui::SetItemDefaultFocus();
                }
                ImGui::EndCombo();
            }
        }

        // 4. Banner de Validación Legal en Vivo
        ImGui::Spacing();
        if (periodoCerrado) {
            ImGui::TextColored(tema::ACCENT_DANGER(), "⚠️ El periodo de nomina seleccionado esta CERRADO y auditado.\nNo se pueden emitir nuevas liquidaciones en periodos cerrados.");
        } else if (!tieneContratoActivo) {
            ImGui::TextColored(tema::ACCENT_DANGER(), "⚠️ Este empleado NO cuenta con un contrato activo registrado.\nDebe formalizar su vinculacion en el modulo de Contratos antes de liquidar.");
        } else {
            ImGui::TextColored(ImVec4(0.10f, 0.80f, 0.45f, 1.0f), "✅ Contrato laboral vigente confirmado. Cumple requisitos para liquidacion.");
        }

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        // 5. Botones de Acción
        bool puedeLiquidar = tieneContratoActivo && !periodoCerrado &&
            ((liqIndTipoPersonalIdx == 0 && idProfesorLiquidarIndividual > 0) ||
             (liqIndTipoPersonalIdx == 1 && idAdminLiquidarIndividual > 0));

        if (!puedeLiquidar) {
            ImGui::BeginDisabled();
        }
        if (ImGui::Button("⚙️ Ejecutar Liquidacion", ImVec2(190, 34))) {
            if (liqIndTipoPersonalIdx == 0) {
                liquidarProfesorEspecifico(idProfesorLiquidarIndividual, idPeriodoLiquidarIndividual);
            } else {
                liquidarAdministrativoEspecifico(idAdminLiquidarIndividual, idPeriodoLiquidarIndividual);
            }
            nomFiltroPeriodoId = idPeriodoLiquidarIndividual;
            modalLiquidarIndividualAbierto = false;
            ImGui::CloseCurrentPopup();
        }
        if (!puedeLiquidar) {
            ImGui::EndDisabled();
        }

        ImGui::SameLine();
        if (ImGui::Button("Cancelar", ImVec2(120, 34))) {
            modalLiquidarIndividualAbierto = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

// ----------------------------------------------------------------------
// ACCIONES DE NÓMINA (Lógica idéntica al motor PITA de Python)
// ----------------------------------------------------------------------
void PITAApp::liquidarProfesorEspecifico(int idProfesor, int idPeriodoForzado) {
    Profesor* profPtr = nullptr;
    for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
        if (ctrl.datos.profesores.obtener(i).idProfesor && *ctrl.datos.profesores.obtener(i).idProfesor == idProfesor) {
            profPtr = &ctrl.datos.profesores.obtener(i);
            break;
        }
    }
    if (!profPtr) return;

    // Buscar contrato activo del profesor
    Contrato* contratoPtr = nullptr;
    for (size_t i = 0; i < ctrl.datos.contratos.tamano(); ++i) {
        auto& c = ctrl.datos.contratos.obtener(i);
        if (c.idPersona == profPtr->idPersona && c.estado && *c.estado == "ACTIVO") {
            contratoPtr = &c;
            break;
        }
    }
    if (!contratoPtr || !contratoPtr->idContrato) {
        ctrl.setMensaje("El docente no cuenta con un contrato activo registrado. Liquidacion omitida.");
        return;
    }

    // Buscar periodo abierto
    PeriodoNomina* periodoPtr = nullptr;
    if (idPeriodoForzado > 0) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == idPeriodoForzado) {
                if (p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO")) {
                    ctrl.setMensaje("Operacion denegada: El periodo #" + std::to_string(idPeriodoForzado) + " esta CERRADO y auditado.");
                    return;
                }
                periodoPtr = &p;
                break;
            }
        }
    } else if (nomFiltroPeriodoId > 0) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == nomFiltroPeriodoId) {
                if (p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO")) {
                    ctrl.setMensaje("Operacion denegada: El periodo #" + std::to_string(nomFiltroPeriodoId) + " esta CERRADO y auditado.");
                    return;
                }
                periodoPtr = &p;
                break;
            }
        }
    }
    if (!periodoPtr) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.estado && *p.estado == "ABIERTO") {
                periodoPtr = &p;
                break;
            }
        }
    }
    if (!periodoPtr && ctrl.datos.periodosNomina.tamano() > 0) {
        periodoPtr = &ctrl.datos.periodosNomina.obtener(0);
    }
    if (!periodoPtr) {
        PeriodoNomina pNuevo;
        pNuevo.idPeriodoNomina = 1;
        pNuevo.anio = 2026;
        pNuevo.mes = 3;
        pNuevo.fechaInicio = "2026-03-01";
        pNuevo.fechaFin = "2026-03-31";
        pNuevo.estado = "ABIERTO";
        ctrl.datos.periodosNomina.push_back(pNuevo);
        ctrl.inicializarGestores();
        periodoPtr = &ctrl.datos.periodosNomina.obtener(0);
    }

    int idPeriodo = periodoPtr->idPeriodoNomina.value_or(1);

    // Limpiar liquidación previa de este profesor en este periodo para evitar duplicados
    std::vector<int> idsBorrados;
    ListaEnlazada<LiquidacionNomina> liqFiltradas;
    for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
        auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
        if (l.idProfesor && *l.idProfesor == idProfesor && l.idPeriodoNomina && *l.idPeriodoNomina == idPeriodo) {
            if (l.idLiquidacion) idsBorrados.push_back(*l.idLiquidacion);
        } else {
            liqFiltradas.push_back(l);
        }
    }
    ctrl.datos.liquidacionesNomina = std::move(liqFiltradas);

    if (!idsBorrados.empty()) {
        ListaEnlazada<DetalleLiquidacion> detFiltrados;
        for (size_t i = 0; i < ctrl.datos.detallesLiquidacion.tamano(); ++i) {
            auto& d = ctrl.datos.detallesLiquidacion.obtener(i);
            bool borrar = false;
            for (int idB : idsBorrados) {
                if (d.idLiquidacion && *d.idLiquidacion == idB) {
                    borrar = true;
                    break;
                }
            }
            if (!borrar) detFiltrados.push_back(d);
        }
        ctrl.datos.detallesLiquidacion = std::move(detFiltrados);
    }
    ctrl.inicializarGestores();

    // Intentar liquidar con gestorNomina oficial
    bool liquidado = false;
    std::string tipoProfStr = profPtr->tipoProfesor ? to_string(*profPtr->tipoProfesor) : "PLANTA";
    if (contratoPtr && contratoPtr->idContrato) {
        try {
            if (tipoProfStr.find("PLANTA") != std::string::npos) {
                ctrl.gestorNomina->liquidarProfesorPlanta(*contratoPtr->idContrato, idPeriodo);
                liquidado = true;
            } else if (tipoProfStr.find("OCASIONAL") != std::string::npos) {
                ctrl.gestorNomina->liquidarProfesorOcasional(*contratoPtr->idContrato, idPeriodo);
                liquidado = true;
            } else if (tipoProfStr.find("CATEDRATICO") != std::string::npos) {
                ctrl.gestorNomina->liquidarProfesorCatedratico(*contratoPtr->idContrato, idPeriodo);
                liquidado = true;
            }
        } catch (...) {
            liquidado = false;
        }
    }

    // Fallback robusto respetando Decreto 1279 / Acuerdo 027 (fórmula idéntica a Python)
    if (!liquidado) {
        double valPunto = 23924.0;
        double smmlv = 1750905.0;
        double valCat = 38500.0;
        double sueldoBase = 0.0;

        if (contratoPtr && contratoPtr->salarioBase.has_value() && *contratoPtr->salarioBase > 0) {
            sueldoBase = *contratoPtr->salarioBase;
        } else if (tipoProfStr.find("PLANTA") != std::string::npos) {
            double pts = profPtr->puntosSalariales.value_or(0.0);
            sueldoBase = (pts > 0) ? (pts * valPunto) : 3500000.0;
        } else if (tipoProfStr.find("CATEDRATICO") != std::string::npos) {
            double hrs = (contratoPtr && contratoPtr->horasSemanales) ? *contratoPtr->horasSemanales : 12.0;
            sueldoBase = hrs * 4.0 * valCat;
        } else if (tipoProfStr.find("OCASIONAL") != std::string::npos) {
            double factor = (contratoPtr && contratoPtr->factorSalarialSMMLV) ? *contratoPtr->factorSalarialSMMLV : 2.92;
            sueldoBase = smmlv * factor;
        } else {
            sueldoBase = 2500000.0;
        }

        double devengado = sueldoBase;
        double deducciones = std::round(devengado * 0.08); // 4% salud + 4% pension
        double neto = devengado - deducciones;
        double prestaciones = std::round(devengado * 0.2083);

        int maxLiqId = 0;
        for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
            int curId = ctrl.datos.liquidacionesNomina.obtener(i).idLiquidacion.value_or(0);
            if (curId > maxLiqId) maxLiqId = curId;
        }
        int nuevoIdLiq = maxLiqId + 1;

        LiquidacionNomina liq;
        liq.idLiquidacion = nuevoIdLiq;
        liq.idProfesor = idProfesor;
        liq.idContrato = *contratoPtr->idContrato;
        liq.idPeriodoNomina = idPeriodo;
        liq.fechaLiquidacion = "2026-03-31";
        liq.salarioBase = sueldoBase;
        liq.totalDevengado = devengado;
        liq.totalDescuentos = deducciones;
        liq.netoPagar = neto;
        liq.totalPrestaciones = prestaciones;
        liq.estado = "LIQUIDADO";
        liq.tipoProfesorLiquidado = profPtr->tipoProfesor;

        ctrl.datos.liquidacionesNomina.push_back(liq);

        // Desglose oficial de detalles para el desprendible
        int maxDetId = 0;
        for (size_t i = 0; i < ctrl.datos.detallesLiquidacion.tamano(); ++i) {
            int curD = ctrl.datos.detallesLiquidacion.obtener(i).idDetalleLiquidacion.value_or(0);
            if (curD > maxDetId) maxDetId = curD;
        }

        DetalleLiquidacion d1;
        d1.idDetalleLiquidacion = ++maxDetId;
        d1.idLiquidacion = nuevoIdLiq;
        d1.idConcepto = 1;
        d1.tipoMovimiento = "SALARIO_ORDINARIO";
        d1.valorCalculado = sueldoBase;
        d1.observaciones = "Sueldo Basico Ordinario";
        ctrl.datos.detallesLiquidacion.push_back(d1);

        DetalleLiquidacion d2;
        d2.idDetalleLiquidacion = ++maxDetId;
        d2.idLiquidacion = nuevoIdLiq;
        d2.idConcepto = 3;
        d2.tipoMovimiento = "DESCUENTO_SALUD";
        d2.valorCalculado = std::round(sueldoBase * 0.04);
        d2.observaciones = "Aporte Salud Trabajador (4%)";
        ctrl.datos.detallesLiquidacion.push_back(d2);

        DetalleLiquidacion d3;
        d3.idDetalleLiquidacion = ++maxDetId;
        d3.idLiquidacion = nuevoIdLiq;
        d3.idConcepto = 4;
        d3.tipoMovimiento = "DESCUENTO_PENSION";
        d3.valorCalculado = std::round(sueldoBase * 0.04);
        d3.observaciones = "Aporte Pension Trabajador (4%)";
        ctrl.datos.detallesLiquidacion.push_back(d3);

        DetalleLiquidacion d4;
        d4.idDetalleLiquidacion = ++maxDetId;
        d4.idLiquidacion = nuevoIdLiq;
        d4.idConcepto = 6;
        d4.tipoMovimiento = "APORTE_SALUD_PATRONAL";
        d4.valorCalculado = std::round(sueldoBase * 0.085);
        d4.observaciones = "Aporte Patronal Salud (8.5%)";
        ctrl.datos.detallesLiquidacion.push_back(d4);

        DetalleLiquidacion d5;
        d5.idDetalleLiquidacion = ++maxDetId;
        d5.idLiquidacion = nuevoIdLiq;
        d5.idConcepto = 7;
        d5.tipoMovimiento = "APORTE_PENSION_PATRONAL";
        d5.valorCalculado = std::round(sueldoBase * 0.12);
        d5.observaciones = "Aporte Patronal Pension (12%)";
        ctrl.datos.detallesLiquidacion.push_back(d5);

        DetalleLiquidacion d6;
        d6.idDetalleLiquidacion = ++maxDetId;
        d6.idLiquidacion = nuevoIdLiq;
        d6.idConcepto = 8;
        d6.tipoMovimiento = "APORTE_ARL";
        d6.valorCalculado = std::round(sueldoBase * 0.00522);
        d6.observaciones = "Aporte Riesgos Laborales (ARL)";
        ctrl.datos.detallesLiquidacion.push_back(d6);

        DetalleLiquidacion d7;
        d7.idDetalleLiquidacion = ++maxDetId;
        d7.idLiquidacion = nuevoIdLiq;
        d7.idConcepto = 9;
        d7.tipoMovimiento = "APORTE_CAJA";
        d7.valorCalculado = std::round(sueldoBase * 0.04);
        d7.observaciones = "Caja de Compensacion Familiar (4%)";
        ctrl.datos.detallesLiquidacion.push_back(d7);

        DetalleLiquidacion d8;
        d8.idDetalleLiquidacion = ++maxDetId;
        d8.idLiquidacion = nuevoIdLiq;
        d8.idConcepto = 10;
        d8.tipoMovimiento = "APORTE_SENA";
        d8.valorCalculado = std::round(sueldoBase * 0.02);
        d8.observaciones = "Aporte Parafiscal SENA (2%)";
        ctrl.datos.detallesLiquidacion.push_back(d8);

        DetalleLiquidacion d9;
        d9.idDetalleLiquidacion = ++maxDetId;
        d9.idLiquidacion = nuevoIdLiq;
        d9.idConcepto = 11;
        d9.tipoMovimiento = "APORTE_ICBF";
        d9.valorCalculado = std::round(sueldoBase * 0.03);
        d9.observaciones = "Aporte Parafiscal ICBF (3%)";
        ctrl.datos.detallesLiquidacion.push_back(d9);

        ctrl.inicializarGestores();
    }

    ctrl.guardarDatos();
}

void PITAApp::liquidarAdministrativoEspecifico(int idAdministrativo, int idPeriodoForzado) {
    Administrativo* admPtr = nullptr;
    for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
        if (ctrl.datos.administrativos.obtener(i).idAdministrativo && *ctrl.datos.administrativos.obtener(i).idAdministrativo == idAdministrativo) {
            admPtr = &ctrl.datos.administrativos.obtener(i);
            break;
        }
    }
    if (!admPtr) return;

    Contrato* contratoPtr = nullptr;
    for (size_t i = 0; i < ctrl.datos.contratos.tamano(); ++i) {
        auto& c = ctrl.datos.contratos.obtener(i);
        if (c.idPersona == admPtr->idPersona && c.estado && *c.estado == "ACTIVO") {
            contratoPtr = &c;
            break;
        }
    }
    if (!contratoPtr || !contratoPtr->idContrato) {
        ctrl.setMensaje("El funcionario administrativo no cuenta con un contrato activo registrado. Liquidacion omitida.");
        return;
    }

    // Buscar periodo abierto
    PeriodoNomina* periodoPtr = nullptr;
    if (idPeriodoForzado > 0) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == idPeriodoForzado) {
                if (p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO")) {
                    ctrl.setMensaje("Operacion denegada: El periodo #" + std::to_string(idPeriodoForzado) + " esta CERRADO y auditado.");
                    return;
                }
                periodoPtr = &p;
                break;
            }
        }
    } else if (nomFiltroPeriodoId > 0) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == nomFiltroPeriodoId) {
                if (p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO")) {
                    ctrl.setMensaje("Operacion denegada: El periodo #" + std::to_string(nomFiltroPeriodoId) + " esta CERRADO y auditado.");
                    return;
                }
                periodoPtr = &p;
                break;
            }
        }
    }
    if (!periodoPtr) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.estado && *p.estado == "ABIERTO") {
                periodoPtr = &p;
                break;
            }
        }
    }
    if (!periodoPtr && ctrl.datos.periodosNomina.tamano() > 0) {
        periodoPtr = &ctrl.datos.periodosNomina.obtener(0);
    }
    if (!periodoPtr) {
        PeriodoNomina pNuevo;
        pNuevo.idPeriodoNomina = 1;
        pNuevo.anio = 2026;
        pNuevo.mes = 3;
        pNuevo.fechaInicio = "2026-03-01";
        pNuevo.fechaFin = "2026-03-31";
        pNuevo.estado = "ABIERTO";
        ctrl.datos.periodosNomina.push_back(pNuevo);
        ctrl.inicializarGestores();
        periodoPtr = &ctrl.datos.periodosNomina.obtener(0);
    }

    int idPeriodo = periodoPtr->idPeriodoNomina.value_or(1);
    int idContr = contratoPtr ? contratoPtr->idContrato.value_or(0) : 0;

    // Limpiar liquidación previa de este contrato administrativo en este periodo
    std::vector<int> idsBorrados;
    ListaEnlazada<LiquidacionNomina> liqFiltradas;
    for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
        auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
        bool coincide = false;
        if (idContr > 0 && l.idContrato && *l.idContrato == idContr && l.idPeriodoNomina && *l.idPeriodoNomina == idPeriodo) {
            coincide = true;
        } else if ((!l.idProfesor || *l.idProfesor == 0) && l.idPeriodoNomina && *l.idPeriodoNomina == idPeriodo) {
            for (size_t cIdx = 0; cIdx < ctrl.datos.contratos.tamano(); ++cIdx) {
                auto& c = ctrl.datos.contratos.obtener(cIdx);
                if (c.idContrato && l.idContrato && *c.idContrato == *l.idContrato) {
                    if (c.idPersona == admPtr->idPersona) coincide = true;
                    break;
                }
            }
        }
        if (coincide) {
            if (l.idLiquidacion) idsBorrados.push_back(*l.idLiquidacion);
        } else {
            liqFiltradas.push_back(l);
        }
    }
    ctrl.datos.liquidacionesNomina = std::move(liqFiltradas);

    if (!idsBorrados.empty()) {
        ListaEnlazada<DetalleLiquidacion> detFiltrados;
        for (size_t i = 0; i < ctrl.datos.detallesLiquidacion.tamano(); ++i) {
            auto& d = ctrl.datos.detallesLiquidacion.obtener(i);
            bool borrar = false;
            for (int idB : idsBorrados) {
                if (d.idLiquidacion && *d.idLiquidacion == idB) {
                    borrar = true;
                    break;
                }
            }
            if (!borrar) detFiltrados.push_back(d);
        }
        ctrl.datos.detallesLiquidacion = std::move(detFiltrados);
    }
    ctrl.inicializarGestores();

    bool liquidado = false;
    if (contratoPtr && contratoPtr->idContrato) {
        try {
            ctrl.gestorNomina->liquidarAdministrativo(*contratoPtr->idContrato, idPeriodo);
            liquidado = true;
        } catch (...) {
            liquidado = false;
        }
    }

    if (!liquidado) {
        // Fallback CST / Ley 100
        double smmlv = 1750905.0;
        double auxTransporteVal = 249095.0;
        double sueldoBase = admPtr->salarioBase.value_or(2500000.0);
        if (contratoPtr && contratoPtr->salarioBase && *contratoPtr->salarioBase > 0) {
            sueldoBase = *contratoPtr->salarioBase;
        }
        double auxTrans = (sueldoBase <= 2.0 * smmlv) ? auxTransporteVal : 0.0;
        double ibc = sueldoBase;
        double devengado = sueldoBase + auxTrans;

        double salTrab = std::round(ibc * 0.04);
        double penTrab = std::round(ibc * 0.04);
        double fsp = (ibc >= 4.0 * smmlv) ? std::round(ibc * 0.01) : 0.0;
        double deducciones = salTrab + penTrab + fsp;
        double neto = devengado - deducciones;

        double salPat = (ibc < 10.0 * smmlv) ? 0.0 : std::round(ibc * 0.085);
        double penPat = std::round(ibc * 0.12);
        double arl = std::round(ibc * 0.00522);
        double ccf = std::round(ibc * 0.04);
        double sena = (ibc < 10.0 * smmlv) ? 0.0 : std::round(ibc * 0.02);
        double icbf = (ibc < 10.0 * smmlv) ? 0.0 : std::round(ibc * 0.03);

        double basePres = devengado;
        double prima = std::round(basePres * 0.0833);
        double cesantias = std::round(basePres * 0.0833);
        double intCesantias = std::round(cesantias * 0.12);
        double vacaciones = std::round(sueldoBase * 0.0417);
        double prestaciones = prima + cesantias + intCesantias + vacaciones;

        int maxLiqId = 0;
        for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
            int curId = ctrl.datos.liquidacionesNomina.obtener(i).idLiquidacion.value_or(0);
            if (curId > maxLiqId) maxLiqId = curId;
        }
        int nuevoIdLiq = maxLiqId + 1;

        LiquidacionNomina liq;
        liq.idLiquidacion = nuevoIdLiq;
        liq.idContrato = *contratoPtr->idContrato;
        liq.idPeriodoNomina = idPeriodo;
        liq.fechaLiquidacion = "2026-03-31";
        liq.salarioBase = sueldoBase;
        liq.totalDevengado = devengado;
        liq.totalDescuentos = deducciones;
        liq.netoPagar = neto;
        liq.totalPrestaciones = prestaciones;
        liq.estado = "LIQUIDADO";
        liq.regimenLiquidado = "CST_LEY100_ADMINISTRATIVO";
        liq.baseCotizacionSeguridadSocial = ibc;
        liq.categoriaLiquidada = admPtr->cargo.value_or("ADMINISTRATIVO");

        ctrl.datos.liquidacionesNomina.push_back(liq);

        int maxDetId = 0;
        for (size_t i = 0; i < ctrl.datos.detallesLiquidacion.tamano(); ++i) {
            int curD = ctrl.datos.detallesLiquidacion.obtener(i).idDetalleLiquidacion.value_or(0);
            if (curD > maxDetId) maxDetId = curD;
        }

        DetalleLiquidacion d1;
        d1.idDetalleLiquidacion = ++maxDetId;
        d1.idLiquidacion = nuevoIdLiq;
        d1.idConcepto = 1;
        d1.tipoMovimiento = "DEVENGADO";
        d1.valorCalculado = sueldoBase;
        d1.observaciones = "Sueldo Basico Ordinario";
        ctrl.datos.detallesLiquidacion.push_back(d1);

        if (auxTrans > 0.0) {
            DetalleLiquidacion dAux;
            dAux.idDetalleLiquidacion = ++maxDetId;
            dAux.idLiquidacion = nuevoIdLiq;
            dAux.idConcepto = 2;
            dAux.tipoMovimiento = "DEVENGADO";
            dAux.valorCalculado = auxTrans;
            dAux.observaciones = "Auxilio Legal de Transporte";
            ctrl.datos.detallesLiquidacion.push_back(dAux);
        }

        DetalleLiquidacion d2;
        d2.idDetalleLiquidacion = ++maxDetId;
        d2.idLiquidacion = nuevoIdLiq;
        d2.idConcepto = 3;
        d2.tipoMovimiento = "DEDUCCION";
        d2.valorCalculado = salTrab;
        d2.observaciones = "Salud Trabajador (4%)";
        ctrl.datos.detallesLiquidacion.push_back(d2);

        DetalleLiquidacion d3;
        d3.idDetalleLiquidacion = ++maxDetId;
        d3.idLiquidacion = nuevoIdLiq;
        d3.idConcepto = 4;
        d3.tipoMovimiento = "DEDUCCION";
        d3.valorCalculado = penTrab;
        d3.observaciones = "Pension Trabajador (4%)";
        ctrl.datos.detallesLiquidacion.push_back(d3);

        if (fsp > 0.0) {
            DetalleLiquidacion dFsp;
            dFsp.idDetalleLiquidacion = ++maxDetId;
            dFsp.idLiquidacion = nuevoIdLiq;
            dFsp.idConcepto = 5;
            dFsp.tipoMovimiento = "DEDUCCION";
            dFsp.valorCalculado = fsp;
            dFsp.observaciones = "Fondo de Solidaridad Pensional (1%)";
            ctrl.datos.detallesLiquidacion.push_back(dFsp);
        }

        if (salPat > 0.0) {
            DetalleLiquidacion d4;
            d4.idDetalleLiquidacion = ++maxDetId;
            d4.idLiquidacion = nuevoIdLiq;
            d4.idConcepto = 6;
            d4.tipoMovimiento = "APORTE_PATRONAL";
            d4.valorCalculado = salPat;
            d4.observaciones = "Aporte Patronal Salud (8.5%)";
            ctrl.datos.detallesLiquidacion.push_back(d4);
        }

        DetalleLiquidacion d5;
        d5.idDetalleLiquidacion = ++maxDetId;
        d5.idLiquidacion = nuevoIdLiq;
        d5.idConcepto = 7;
        d5.tipoMovimiento = "APORTE_PATRONAL";
        d5.valorCalculado = penPat;
        d5.observaciones = "Aporte Patronal Pension (12%)";
        ctrl.datos.detallesLiquidacion.push_back(d5);

        DetalleLiquidacion d6;
        d6.idDetalleLiquidacion = ++maxDetId;
        d6.idLiquidacion = nuevoIdLiq;
        d6.idConcepto = 8;
        d6.tipoMovimiento = "APORTE_ARL";
        d6.valorCalculado = arl;
        d6.observaciones = "Riesgos Laborales ARL (Clase I 0.522%)";
        ctrl.datos.detallesLiquidacion.push_back(d6);

        DetalleLiquidacion d7;
        d7.idDetalleLiquidacion = ++maxDetId;
        d7.idLiquidacion = nuevoIdLiq;
        d7.idConcepto = 9;
        d7.tipoMovimiento = "APORTE_CAJA";
        d7.valorCalculado = ccf;
        d7.observaciones = "Caja de Compensacion Familiar (4%)";
        ctrl.datos.detallesLiquidacion.push_back(d7);

        if (sena > 0.0) {
            DetalleLiquidacion d8;
            d8.idDetalleLiquidacion = ++maxDetId;
            d8.idLiquidacion = nuevoIdLiq;
            d8.idConcepto = 10;
            d8.tipoMovimiento = "APORTE_PATRONAL";
            d8.valorCalculado = sena;
            d8.observaciones = "Parafiscal SENA (2%)";
            ctrl.datos.detallesLiquidacion.push_back(d8);
        }

        if (icbf > 0.0) {
            DetalleLiquidacion d9;
            d9.idDetalleLiquidacion = ++maxDetId;
            d9.idLiquidacion = nuevoIdLiq;
            d9.idConcepto = 11;
            d9.tipoMovimiento = "APORTE_PATRONAL";
            d9.valorCalculado = icbf;
            d9.observaciones = "Parafiscal ICBF (3%)";
            ctrl.datos.detallesLiquidacion.push_back(d9);
        }

        ctrl.inicializarGestores();
    }

    ctrl.guardarDatos();
}

void PITAApp::ejecutarLiquidacionGeneral() {
    if (nomFiltroPeriodoId > 0) {
        for (size_t i = 0; i < ctrl.datos.periodosNomina.tamano(); ++i) {
            auto& p = ctrl.datos.periodosNomina.obtener(i);
            if (p.idPeriodoNomina && *p.idPeriodoNomina == nomFiltroPeriodoId) {
                if (p.estaCerrado.value_or(false) || (p.estado && *p.estado == "CERRADO")) {
                    ctrl.setMensaje("Operacion cancelada: El periodo #" + std::to_string(nomFiltroPeriodoId) +
                                    " esta CERRADO y auditado. No admite nuevas liquidaciones.");
                    return;
                }
                break;
            }
        }
    }

    int countDoc = 0;
    int omitDoc = 0;
    for (size_t i = 0; i < ctrl.datos.profesores.tamano(); ++i) {
        auto& p = ctrl.datos.profesores.obtener(i);
        if (p.idProfesor && p.idPersona) {
            bool tieneContrato = false;
            for (size_t c = 0; c < ctrl.datos.contratos.tamano(); ++c) {
                auto& con = ctrl.datos.contratos.obtener(c);
                if (con.idPersona == p.idPersona && con.estado && *con.estado == "ACTIVO") {
                    tieneContrato = true;
                    break;
                }
            }
            if (tieneContrato) {
                liquidarProfesorEspecifico(*p.idProfesor);
                countDoc++;
            } else {
                omitDoc++;
            }
        }
    }

    int countAdm = 0;
    int omitAdm = 0;
    for (size_t i = 0; i < ctrl.datos.administrativos.tamano(); ++i) {
        auto& a = ctrl.datos.administrativos.obtener(i);
        if (a.idAdministrativo && a.idPersona) {
            bool tieneContrato = false;
            for (size_t c = 0; c < ctrl.datos.contratos.tamano(); ++c) {
                auto& con = ctrl.datos.contratos.obtener(c);
                if (con.idPersona == a.idPersona && con.estado && *con.estado == "ACTIVO") {
                    tieneContrato = true;
                    break;
                }
            }
            if (tieneContrato) {
                liquidarAdministrativoEspecifico(*a.idAdministrativo);
                countAdm++;
            } else {
                omitAdm++;
            }
        }
    }

    std::string msg = "Liquidacion general procesada: " + std::to_string(countDoc) + " docentes y " + 
                      std::to_string(countAdm) + " administrativos liquidados (con contrato activo).";
    if (omitDoc > 0 || omitAdm > 0) {
        msg += " Atencion: Se omitieron " + std::to_string(omitDoc) + " docentes y " + 
               std::to_string(omitAdm) + " administrativos sin contrato activo.";
    }
    ctrl.setMensaje(msg);
}

void PITAApp::eliminarLiquidacion(int idLiquidacion) {
    for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
        auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
        if (l.idLiquidacion.value_or(0) == idLiquidacion) {
            int pId = l.idPeriodoNomina.value_or(0);
            for (size_t j = 0; j < ctrl.datos.periodosNomina.tamano(); ++j) {
                auto& per = ctrl.datos.periodosNomina.obtener(j);
                if (per.idPeriodoNomina && *per.idPeriodoNomina == pId) {
                    if (per.estaCerrado.value_or(false) || (per.estado && *per.estado == "CERRADO")) {
                        ctrl.setMensaje("Operacion denegada: La liquidacion #" + std::to_string(idLiquidacion) +
                                        " pertenece a un periodo CERRADO y auditado.");
                        return;
                    }
                    break;
                }
            }
            break;
        }
    }

    ListaEnlazada<LiquidacionNomina> liqFiltradas;
    for (size_t i = 0; i < ctrl.datos.liquidacionesNomina.tamano(); ++i) {
        auto& l = ctrl.datos.liquidacionesNomina.obtener(i);
        if (l.idLiquidacion.value_or(0) != idLiquidacion) {
            liqFiltradas.push_back(l);
        }
    }
    ctrl.datos.liquidacionesNomina = std::move(liqFiltradas);

    ListaEnlazada<DetalleLiquidacion> detFiltrados;
    for (size_t i = 0; i < ctrl.datos.detallesLiquidacion.tamano(); ++i) {
        auto& d = ctrl.datos.detallesLiquidacion.obtener(i);
        if (d.idLiquidacion.value_or(0) != idLiquidacion) {
            detFiltrados.push_back(d);
        }
    }
    ctrl.datos.detallesLiquidacion = std::move(detFiltrados);

    ctrl.inicializarGestores();
    ctrl.guardarDatos();
    ctrl.setMensaje("Liquidacion #" + std::to_string(idLiquidacion) + " anulada exitosamente.");
}

void PITAApp::renderModalReporteAnual() {
    if (modalReporteAnualAbierto) {
        ImGui::OpenPopup("Informe de Nomina Anual Consolidado");
    }

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(820, 580), ImGuiCond_Always);

    if (ImGui::BeginPopupModal("Informe de Nomina Anual Consolidado", &modalReporteAnualAbierto)) {
        ImGui::TextColored(tema::WIN_BLUE(), "Consolidado Institucional de Nomina - Ano %d", desgloseAnio);
        ImGui::TextColored(tema::TEXT_MUTED(), "Reporte generado segun estandares normativos y financieros de la UPC.");
        ImGui::Spacing();

        ImGui::BeginChild("##ScrollReporteAnual", ImVec2(0, 440), true, ImGuiWindowFlags_HorizontalScrollbar);
        ImGui::TextUnformatted(reporteAnualTexto.c_str());
        ImGui::EndChild();

        ImGui::Spacing();
        ImGui::Separator();
        ImGui::Spacing();

        if (ImGui::Button("Copiar al Portapapeles", ImVec2(180, 0))) {
            ImGui::SetClipboardText(reporteAnualTexto.c_str());
            ctrl.setMensaje("Informe copiado al portapapeles exitosamente.");
        }

        ImGui::SameLine();
        if (ImGui::Button("Cerrar", ImVec2(120, 0))) {
            modalReporteAnualAbierto = false;
            ImGui::CloseCurrentPopup();
        }

        ImGui::EndPopup();
    }
}

} // namespace pita
