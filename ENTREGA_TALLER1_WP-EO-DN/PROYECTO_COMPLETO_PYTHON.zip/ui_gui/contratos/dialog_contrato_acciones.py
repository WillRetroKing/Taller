"""Modales de acciones sobre contratos: Ver Ficha Técnica, Editar y Terminar."""

from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import TYPE_CHECKING, Callable
import customtkinter as ctk

from ui_gui.theme import Colors
from ui_gui.components import clean_enum

if TYPE_CHECKING:
    from ui_gui.gui_controller import PITAController
    from ui_gui.contratos.contratos_service import ContratosService
    from dominio.modelo_datos import Contrato


class DialogDetalleContrato(ctk.CTkToplevel):
    """Ficha Técnica consolidada de una vinculación contractual."""

    def __init__(
        self,
        parent: ctk.CTkBaseClass,
        contrato: Contrato,
        controller: PITAController,
        service: ContratosService,
    ) -> None:
        super().__init__(parent)
        self.contrato = contrato
        self.controller = controller
        self.service = service

        self.title(f"📄 Ficha Técnica Contractual — {contrato.numeroContrato}")
        self.geometry("560x650")
        self.transient(parent.winfo_toplevel())
        self.grab_set()

        self._construir_ui()

    def _construir_ui(self) -> None:
        c = self.contrato
        prof = self.service.buscar_profesor_por_id(c.idPersona)
        pers = self.service.buscar_persona_por_id(getattr(prof, "idPersona", None)) or self.service.buscar_persona_por_id(c.idPersona)
        nom_prof = f"{getattr(pers, 'primerNombre', '')} {getattr(pers, 'primerApellido', '')}" if pers else f"Docente #{c.idPersona}"

        ctk.CTkLabel(self, text=f"🏛️ VINCULACIÓN: {c.numeroContrato}", font=ctk.CTkFont(family="Segoe UI", size=15, weight="bold"), text_color=Colors.WIN_BLUE).pack(pady=(16, 2))
        ctk.CTkLabel(self, text="Ficha Técnica Consolidada y Formalización de Nómina PITA", font=ctk.CTkFont(family="Segoe UI", size=11), text_color=Colors.TEXT_MUTED).pack(pady=(0, 10))

        scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=16, pady=4)

        card = ctk.CTkFrame(scroll, fg_color=Colors.BG_CARD, corner_radius=8, border_width=1, border_color=Colors.BORDER_SUBTLE)
        card.pack(fill="x", pady=6)

        asig = str(getattr(c, "salarioBase", "0") or getattr(c, "salarioMensualPactado", "0") or "0")
        try:
            asig_fmt = f"$ {int(float(asig)):,} COP"
        except Exception:
            asig_fmt = f"$ {asig}"

        mod = clean_enum(getattr(c, "modalidadProfesor", "") or getattr(c, "tipoContrato", "DOCENTE")).upper()
        adm = self.service.buscar_administrativo_por_id_persona(c.idPersona)
        es_admin = "ADMIN" in mod or (getattr(c, "regimenAplicable", "") == "CST_LEY100_ADMINISTRATIVO") or (adm is not None)

        if es_admin:
            nom_empleado = f"{getattr(pers, 'primerNombre', '')} {getattr(pers, 'primerApellido', '')}" if pers else f"Funcionario #{c.idPersona}"
            regimen = "Código Sustantivo del Trabajo (CST / Ley 100 de 1993)"
            cargo_str = getattr(adm, "cargo", "Administrativo") if adm else "Administrativo"
            dep_str = getattr(adm, "dependencia", "Vicerrectoría") if adm else "N/D"
            cat_str = getattr(adm, "categoria", "PROFESIONAL") if adm else "PROFESIONAL"
            aux_str = "Aplica ($249.095 COP)" if getattr(c, "aplicaAuxilioTransporte", False) else "No Aplica (> 2 SMMLV)"

            items = [
                ("Funcionario Vinculado:", nom_empleado),
                ("Documento de Identidad:", str(getattr(pers, "numeroDocumento", "N/D"))),
                ("Cargo Institucional:", cargo_str),
                ("Dependencia / Área:", dep_str),
                ("Nivel / Categoría:", cat_str),
                ("Modalidad Contractual:", clean_enum(getattr(c, "tipoContrato", "TERMINO_INDEFINIDO"))),
                ("Régimen Jurídico:", regimen),
                ("Asignación Básica Mensual:", asig_fmt),
                ("Auxilio Legal de Transporte:", aux_str),
                ("Horas Semanales:", f"{getattr(c, 'horasSemanales', 40)} horas/semana"),
                ("Fecha de Inicio:", str(getattr(c, "fechaInicio", "N/D"))),
                ("Fecha de Terminación:", str(getattr(c, "fechaFin", "Indefinido"))),
                ("Estado del Contrato:", clean_enum(getattr(c, "estado", "ACTIVO")).upper()),
                ("Clase de Riesgo ARL:", str(getattr(c, "claseARL", getattr(c, "claseRiesgoARL", "CLASE I (0.522%)")))),
                ("Supervisión Inmediata:", "Dirección de Talento Humano / Dependencia"),
            ]
        else:
            regimen = "Carrera Docente (Decreto 1279/2002)" if "PLANTA" in mod else "Docente Transitorio (Acuerdo 027/2024)"
            pts_sal = getattr(prof, "puntosSalariales", 0) or 0
            cat_doc = clean_enum(getattr(prof, "categoriaDocente", "N/A")).replace("_", " ").title()
            ded_fmt = clean_enum(getattr(c, "dedicacion", "TIEMPO_COMPLETO")).replace("_", " ").title()

            items = [
                ("Docente Vinculado:", nom_prof),
                ("Documento de Identidad:", str(getattr(pers, "numeroDocumento", "N/D"))),
                ("Modalidad Contractual:", mod),
                ("Régimen Jurídico:", regimen),
                ("Categoría Docente:", cat_doc),
                ("Puntos Salariales (Dec. 1279):", f"{pts_sal} puntos"),
                ("Dedicación:", ded_fmt),
                ("Horas Semanales:", f"{getattr(c, 'horasSemanales', 40)} horas/semana"),
                ("Asignación Básica Mensual:", asig_fmt),
                ("Fecha de Inicio:", str(getattr(c, "fechaInicio", "N/D"))),
                ("Fecha de Terminación:", str(getattr(c, "fechaFin", "Indefinido"))),
                ("Estado:", clean_enum(getattr(c, "estado", "ACTIVO")).upper()),
                ("Disponibilidad Presupuestal (CDP):", str(getattr(c, "numeroCDP", "N/A"))),
                ("Resolución de Nombramiento:", str(getattr(c, "resolucionNombramiento", "N/A"))),
                ("Clase de Riesgo ARL:", str(getattr(c, "claseARL", getattr(c, "claseRiesgoARL", "CLASE I (0.522%)")))),
                ("Supervisión / Decanatura:", "Decano de Facultad / Vicerrectoría"),
            ]

        for lbl, val in items:
            row = ctk.CTkFrame(card, fg_color="transparent")
            row.pack(fill="x", padx=14, pady=3)
            ctk.CTkLabel(row, text=lbl, font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"), text_color=Colors.TEXT_MUTED).pack(side="left")
            ctk.CTkLabel(row, text=val, font=ctk.CTkFont(family="Segoe UI", size=11), text_color=Colors.TEXT_MAIN).pack(side="right")


class DialogTerminarContrato(ctk.CTkToplevel):
    """Diálogo modal para terminar y liquidar una vinculación contractual."""

    def __init__(
        self,
        parent: ctk.CTkBaseClass,
        contrato: Contrato,
        controller: PITAController,
        service: ContratosService,
        on_success: Callable[[], None],
    ) -> None:
        super().__init__(parent)
        self.contrato = contrato
        self.controller = controller
        self.service = service
        self.on_success = on_success

        self.title(f"🚫 Terminar Contrato {contrato.numeroContrato}")
        self.geometry("480x420")
        self.transient(parent.winfo_toplevel())
        self.grab_set()

        self._construir_ui()

    def _construir_ui(self) -> None:
        c = self.contrato
        ctk.CTkLabel(self, text=f"🚫 Terminación de Contrato {c.numeroContrato}", font=ctk.CTkFont(family="Segoe UI", size=16, weight="bold"), text_color="#EF4444").pack(pady=(16, 2))
        ctk.CTkLabel(self, text="Esta acción finalizará la vinculación y habilitará la liquidación definitiva", font=ctk.CTkFont(family="Segoe UI", size=11), text_color=Colors.TEXT_MUTED).pack(pady=(0, 12))

        card = ctk.CTkFrame(self, fg_color=Colors.BG_CARD, corner_radius=8, border_width=1, border_color=Colors.BORDER_SUBTLE)
        card.pack(fill="x", padx=20, pady=6)

        ctk.CTkLabel(card, text="Causal de Terminación:", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold")).pack(anchor="w", padx=14, pady=(10, 2))
        combo_motivo = ctk.CTkComboBox(
            card,
            values=[
                "Cumplimiento del Plazo Pactado",
                "Renuncia Aceptada",
                "Mutuo Acuerdo de las Partes",
                "Despido Justificado / Incumplimiento",
                "Inhabilidad Sobreveniente",
            ],
            width=380,
        )
        combo_motivo.pack(fill="x", padx=14, pady=(0, 8))

        ctk.CTkLabel(card, text="Fecha Efectiva de Terminación (YYYY-MM-DD):", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold")).pack(anchor="w", padx=14, pady=(4, 2))
        entry_f_term = ctk.CTkEntry(card)
        entry_f_term.insert(0, date.today().isoformat())
        entry_f_term.pack(fill="x", padx=14, pady=(0, 8))

        chk_liq = ctk.CTkCheckBox(card, text="Confirmar Liquidación de Prestaciones Sociales y Cesantías")
        chk_liq.select()
        chk_liq.pack(anchor="w", padx=14, pady=(4, 12))

        lbl_err = ctk.CTkLabel(self, text="", text_color="#EF4444", font=ctk.CTkFont(family="Segoe UI", size=11, weight="bold"))
        lbl_err.pack(pady=2)

        def _terminar():
            try:
                f_term = date.fromisoformat(entry_f_term.get().strip())
            except ValueError:
                lbl_err.configure(text="⚠️ Fecha de terminación inválida.")
                return

            motivo = combo_motivo.get()
            self.service.terminar_contrato(self.contrato, motivo, f_term)
            self.destroy()
            self.on_success()

        ctk.CTkButton(
            self,
            text="🚫 Confirmar y Terminar Vinculación",
            font=ctk.CTkFont(family="Segoe UI", size=12, weight="bold"),
            fg_color="#EF4444",
            hover_color="#DC2626",
            height=38,
            command=_terminar,
        ).pack(fill="x", padx=20, pady=(10, 16))
